CREATE TABLE mInfo
(
    "m_num"   int            NOT NULL, 
    "lent"    varchar(50)    NULL, 
    "pt"      varchar(50)    NULL, 
    "t_num"   int            NULL, 
    "health"  varchar(50)    NULL   
)
ALTER TABLE mInfo
    ADD CONSTRAINT FK_mInfo_m_num_member_m_num FOREIGN KEY (m_num)
        REFERENCES member (m_num)
ALTER TABLE mInfo
    ADD CONSTRAINT FK_mInfo_t_num_trainer_t_num FOREIGN KEY (t_num)
        REFERENCES trainer (t_num)