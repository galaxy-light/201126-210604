﻿
namespace KIMHealth.Ui
{
    partial class Locker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Locker));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.WhatTime = new System.Windows.Forms.TextBox();
            this.lock_1 = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lock_2 = new System.Windows.Forms.Label();
            this.lock_3 = new System.Windows.Forms.Label();
            this.lock_4 = new System.Windows.Forms.Label();
            this.lock_5 = new System.Windows.Forms.Label();
            this.lock_10 = new System.Windows.Forms.Label();
            this.lock_9 = new System.Windows.Forms.Label();
            this.lock_8 = new System.Windows.Forms.Label();
            this.lock_7 = new System.Windows.Forms.Label();
            this.lock_6 = new System.Windows.Forms.Label();
            this.lock_15 = new System.Windows.Forms.Label();
            this.lock_14 = new System.Windows.Forms.Label();
            this.lock_13 = new System.Windows.Forms.Label();
            this.lock_12 = new System.Windows.Forms.Label();
            this.lock_11 = new System.Windows.Forms.Label();
            this.lock_20 = new System.Windows.Forms.Label();
            this.lock_19 = new System.Windows.Forms.Label();
            this.lock_18 = new System.Windows.Forms.Label();
            this.lock_17 = new System.Windows.Forms.Label();
            this.lock_16 = new System.Windows.Forms.Label();
            this.lock_30 = new System.Windows.Forms.Label();
            this.lock_29 = new System.Windows.Forms.Label();
            this.lock_28 = new System.Windows.Forms.Label();
            this.lock_27 = new System.Windows.Forms.Label();
            this.lock_26 = new System.Windows.Forms.Label();
            this.lock_25 = new System.Windows.Forms.Label();
            this.lock_24 = new System.Windows.Forms.Label();
            this.lock_23 = new System.Windows.Forms.Label();
            this.lock_22 = new System.Windows.Forms.Label();
            this.lock_21 = new System.Windows.Forms.Label();
            this.lock_40 = new System.Windows.Forms.Label();
            this.lock_39 = new System.Windows.Forms.Label();
            this.lock_38 = new System.Windows.Forms.Label();
            this.lock_37 = new System.Windows.Forms.Label();
            this.lock_36 = new System.Windows.Forms.Label();
            this.lock_35 = new System.Windows.Forms.Label();
            this.lock_34 = new System.Windows.Forms.Label();
            this.lock_33 = new System.Windows.Forms.Label();
            this.lock_32 = new System.Windows.Forms.Label();
            this.lock_31 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // WhatTime
            // 
            this.WhatTime.Location = new System.Drawing.Point(45, 506);
            this.WhatTime.Name = "WhatTime";
            this.WhatTime.Size = new System.Drawing.Size(100, 21);
            this.WhatTime.TabIndex = 0;
            // 
            // lock_1
            // 
            this.lock_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_1.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_1.Location = new System.Drawing.Point(42, 44);
            this.lock_1.Name = "lock_1";
            this.lock_1.Size = new System.Drawing.Size(50, 70);
            this.lock_1.TabIndex = 1;
            this.lock_1.Text = "1";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 505);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(821, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // lock_2
            // 
            this.lock_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_2.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_2.Location = new System.Drawing.Point(111, 44);
            this.lock_2.Name = "lock_2";
            this.lock_2.Size = new System.Drawing.Size(50, 70);
            this.lock_2.TabIndex = 2;
            this.lock_2.Text = "2";
            // 
            // lock_3
            // 
            this.lock_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_3.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_3.Location = new System.Drawing.Point(180, 44);
            this.lock_3.Name = "lock_3";
            this.lock_3.Size = new System.Drawing.Size(50, 70);
            this.lock_3.TabIndex = 3;
            this.lock_3.Text = "3";
            // 
            // lock_4
            // 
            this.lock_4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_4.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_4.Location = new System.Drawing.Point(249, 44);
            this.lock_4.Name = "lock_4";
            this.lock_4.Size = new System.Drawing.Size(50, 70);
            this.lock_4.TabIndex = 4;
            this.lock_4.Text = "4";
            // 
            // lock_5
            // 
            this.lock_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_5.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_5.Location = new System.Drawing.Point(318, 44);
            this.lock_5.Name = "lock_5";
            this.lock_5.Size = new System.Drawing.Size(50, 70);
            this.lock_5.TabIndex = 5;
            this.lock_5.Text = "5";
            // 
            // lock_10
            // 
            this.lock_10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_10.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_10.Location = new System.Drawing.Point(663, 44);
            this.lock_10.Name = "lock_10";
            this.lock_10.Size = new System.Drawing.Size(50, 70);
            this.lock_10.TabIndex = 10;
            this.lock_10.Text = "10";
            // 
            // lock_9
            // 
            this.lock_9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_9.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_9.Location = new System.Drawing.Point(594, 44);
            this.lock_9.Name = "lock_9";
            this.lock_9.Size = new System.Drawing.Size(50, 70);
            this.lock_9.TabIndex = 9;
            this.lock_9.Text = "9";
            // 
            // lock_8
            // 
            this.lock_8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_8.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_8.Location = new System.Drawing.Point(525, 44);
            this.lock_8.Name = "lock_8";
            this.lock_8.Size = new System.Drawing.Size(50, 70);
            this.lock_8.TabIndex = 8;
            this.lock_8.Text = "8";
            // 
            // lock_7
            // 
            this.lock_7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_7.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_7.Location = new System.Drawing.Point(456, 44);
            this.lock_7.Name = "lock_7";
            this.lock_7.Size = new System.Drawing.Size(50, 70);
            this.lock_7.TabIndex = 7;
            this.lock_7.Text = "7";
            // 
            // lock_6
            // 
            this.lock_6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_6.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_6.Location = new System.Drawing.Point(387, 44);
            this.lock_6.Name = "lock_6";
            this.lock_6.Size = new System.Drawing.Size(50, 70);
            this.lock_6.TabIndex = 6;
            this.lock_6.Text = "6";
            // 
            // lock_15
            // 
            this.lock_15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_15.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_15.Location = new System.Drawing.Point(318, 136);
            this.lock_15.Name = "lock_15";
            this.lock_15.Size = new System.Drawing.Size(50, 70);
            this.lock_15.TabIndex = 15;
            this.lock_15.Text = "15";
            // 
            // lock_14
            // 
            this.lock_14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_14.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_14.Location = new System.Drawing.Point(249, 136);
            this.lock_14.Name = "lock_14";
            this.lock_14.Size = new System.Drawing.Size(50, 70);
            this.lock_14.TabIndex = 14;
            this.lock_14.Text = "14";
            // 
            // lock_13
            // 
            this.lock_13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_13.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_13.Location = new System.Drawing.Point(180, 136);
            this.lock_13.Name = "lock_13";
            this.lock_13.Size = new System.Drawing.Size(50, 70);
            this.lock_13.TabIndex = 13;
            this.lock_13.Text = "13";
            // 
            // lock_12
            // 
            this.lock_12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_12.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_12.Location = new System.Drawing.Point(111, 136);
            this.lock_12.Name = "lock_12";
            this.lock_12.Size = new System.Drawing.Size(50, 70);
            this.lock_12.TabIndex = 12;
            this.lock_12.Text = "12";
            // 
            // lock_11
            // 
            this.lock_11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_11.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_11.Location = new System.Drawing.Point(42, 136);
            this.lock_11.Name = "lock_11";
            this.lock_11.Size = new System.Drawing.Size(50, 70);
            this.lock_11.TabIndex = 11;
            this.lock_11.Text = "11";
            // 
            // lock_20
            // 
            this.lock_20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_20.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_20.Location = new System.Drawing.Point(663, 136);
            this.lock_20.Name = "lock_20";
            this.lock_20.Size = new System.Drawing.Size(50, 70);
            this.lock_20.TabIndex = 20;
            this.lock_20.Text = "20";
            // 
            // lock_19
            // 
            this.lock_19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_19.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_19.Location = new System.Drawing.Point(594, 136);
            this.lock_19.Name = "lock_19";
            this.lock_19.Size = new System.Drawing.Size(50, 70);
            this.lock_19.TabIndex = 19;
            this.lock_19.Text = "19";
            // 
            // lock_18
            // 
            this.lock_18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_18.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_18.Location = new System.Drawing.Point(525, 136);
            this.lock_18.Name = "lock_18";
            this.lock_18.Size = new System.Drawing.Size(50, 70);
            this.lock_18.TabIndex = 18;
            this.lock_18.Text = "18";
            // 
            // lock_17
            // 
            this.lock_17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_17.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_17.Location = new System.Drawing.Point(456, 136);
            this.lock_17.Name = "lock_17";
            this.lock_17.Size = new System.Drawing.Size(50, 70);
            this.lock_17.TabIndex = 17;
            this.lock_17.Text = "17";
            // 
            // lock_16
            // 
            this.lock_16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_16.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_16.Location = new System.Drawing.Point(387, 136);
            this.lock_16.Name = "lock_16";
            this.lock_16.Size = new System.Drawing.Size(50, 70);
            this.lock_16.TabIndex = 16;
            this.lock_16.Text = "16";
            // 
            // lock_30
            // 
            this.lock_30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_30.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_30.Location = new System.Drawing.Point(663, 230);
            this.lock_30.Name = "lock_30";
            this.lock_30.Size = new System.Drawing.Size(50, 70);
            this.lock_30.TabIndex = 30;
            this.lock_30.Text = "30";
            // 
            // lock_29
            // 
            this.lock_29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_29.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_29.Location = new System.Drawing.Point(594, 230);
            this.lock_29.Name = "lock_29";
            this.lock_29.Size = new System.Drawing.Size(50, 70);
            this.lock_29.TabIndex = 29;
            this.lock_29.Text = "29";
            // 
            // lock_28
            // 
            this.lock_28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_28.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_28.Location = new System.Drawing.Point(525, 230);
            this.lock_28.Name = "lock_28";
            this.lock_28.Size = new System.Drawing.Size(50, 70);
            this.lock_28.TabIndex = 28;
            this.lock_28.Text = "28";
            // 
            // lock_27
            // 
            this.lock_27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_27.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_27.Location = new System.Drawing.Point(456, 230);
            this.lock_27.Name = "lock_27";
            this.lock_27.Size = new System.Drawing.Size(50, 70);
            this.lock_27.TabIndex = 27;
            this.lock_27.Text = "27";
            // 
            // lock_26
            // 
            this.lock_26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_26.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_26.Location = new System.Drawing.Point(387, 230);
            this.lock_26.Name = "lock_26";
            this.lock_26.Size = new System.Drawing.Size(50, 70);
            this.lock_26.TabIndex = 26;
            this.lock_26.Text = "26";
            // 
            // lock_25
            // 
            this.lock_25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_25.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_25.Location = new System.Drawing.Point(318, 230);
            this.lock_25.Name = "lock_25";
            this.lock_25.Size = new System.Drawing.Size(50, 70);
            this.lock_25.TabIndex = 25;
            this.lock_25.Text = "25";
            // 
            // lock_24
            // 
            this.lock_24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_24.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_24.Location = new System.Drawing.Point(249, 230);
            this.lock_24.Name = "lock_24";
            this.lock_24.Size = new System.Drawing.Size(50, 70);
            this.lock_24.TabIndex = 24;
            this.lock_24.Text = "24";
            // 
            // lock_23
            // 
            this.lock_23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_23.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_23.Location = new System.Drawing.Point(180, 230);
            this.lock_23.Name = "lock_23";
            this.lock_23.Size = new System.Drawing.Size(50, 70);
            this.lock_23.TabIndex = 23;
            this.lock_23.Text = "23";
            // 
            // lock_22
            // 
            this.lock_22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_22.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_22.Location = new System.Drawing.Point(111, 230);
            this.lock_22.Name = "lock_22";
            this.lock_22.Size = new System.Drawing.Size(50, 70);
            this.lock_22.TabIndex = 22;
            this.lock_22.Text = "22";
            // 
            // lock_21
            // 
            this.lock_21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_21.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_21.Location = new System.Drawing.Point(42, 230);
            this.lock_21.Name = "lock_21";
            this.lock_21.Size = new System.Drawing.Size(50, 70);
            this.lock_21.TabIndex = 21;
            this.lock_21.Text = "21";
            // 
            // lock_40
            // 
            this.lock_40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_40.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_40.Location = new System.Drawing.Point(663, 320);
            this.lock_40.Name = "lock_40";
            this.lock_40.Size = new System.Drawing.Size(50, 70);
            this.lock_40.TabIndex = 40;
            this.lock_40.Text = "40";
            // 
            // lock_39
            // 
            this.lock_39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_39.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_39.Location = new System.Drawing.Point(594, 320);
            this.lock_39.Name = "lock_39";
            this.lock_39.Size = new System.Drawing.Size(50, 70);
            this.lock_39.TabIndex = 39;
            this.lock_39.Text = "39";
            // 
            // lock_38
            // 
            this.lock_38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_38.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_38.Location = new System.Drawing.Point(525, 320);
            this.lock_38.Name = "lock_38";
            this.lock_38.Size = new System.Drawing.Size(50, 70);
            this.lock_38.TabIndex = 38;
            this.lock_38.Text = "38";
            // 
            // lock_37
            // 
            this.lock_37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_37.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_37.Location = new System.Drawing.Point(456, 320);
            this.lock_37.Name = "lock_37";
            this.lock_37.Size = new System.Drawing.Size(50, 70);
            this.lock_37.TabIndex = 37;
            this.lock_37.Text = "37";
            // 
            // lock_36
            // 
            this.lock_36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_36.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_36.Location = new System.Drawing.Point(387, 320);
            this.lock_36.Name = "lock_36";
            this.lock_36.Size = new System.Drawing.Size(50, 70);
            this.lock_36.TabIndex = 36;
            this.lock_36.Text = "36";
            // 
            // lock_35
            // 
            this.lock_35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_35.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_35.Location = new System.Drawing.Point(318, 320);
            this.lock_35.Name = "lock_35";
            this.lock_35.Size = new System.Drawing.Size(50, 70);
            this.lock_35.TabIndex = 35;
            this.lock_35.Text = "35";
            // 
            // lock_34
            // 
            this.lock_34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_34.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_34.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lock_34.Location = new System.Drawing.Point(249, 320);
            this.lock_34.Name = "lock_34";
            this.lock_34.Size = new System.Drawing.Size(50, 70);
            this.lock_34.TabIndex = 34;
            this.lock_34.Text = "34";
            // 
            // lock_33
            // 
            this.lock_33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_33.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_33.Location = new System.Drawing.Point(180, 320);
            this.lock_33.Name = "lock_33";
            this.lock_33.Size = new System.Drawing.Size(50, 70);
            this.lock_33.TabIndex = 33;
            this.lock_33.Text = "33";
            // 
            // lock_32
            // 
            this.lock_32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_32.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_32.Location = new System.Drawing.Point(111, 320);
            this.lock_32.Name = "lock_32";
            this.lock_32.Size = new System.Drawing.Size(50, 70);
            this.lock_32.TabIndex = 32;
            this.lock_32.Text = "32";
            // 
            // lock_31
            // 
            this.lock_31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lock_31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lock_31.Font = new System.Drawing.Font("HY수평선B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lock_31.Location = new System.Drawing.Point(42, 320);
            this.lock_31.Name = "lock_31";
            this.lock_31.Size = new System.Drawing.Size(50, 70);
            this.lock_31.TabIndex = 31;
            this.lock_31.Text = "31";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(773, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(36, 29);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 42;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(720, 9);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(36, 29);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 43;
            this.pictureBox3.TabStop = false;
            // 
            // Locker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(821, 527);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lock_40);
            this.Controls.Add(this.lock_39);
            this.Controls.Add(this.lock_38);
            this.Controls.Add(this.lock_37);
            this.Controls.Add(this.lock_36);
            this.Controls.Add(this.lock_35);
            this.Controls.Add(this.lock_34);
            this.Controls.Add(this.lock_33);
            this.Controls.Add(this.lock_32);
            this.Controls.Add(this.lock_31);
            this.Controls.Add(this.lock_30);
            this.Controls.Add(this.lock_29);
            this.Controls.Add(this.lock_28);
            this.Controls.Add(this.lock_27);
            this.Controls.Add(this.lock_26);
            this.Controls.Add(this.lock_25);
            this.Controls.Add(this.lock_24);
            this.Controls.Add(this.lock_23);
            this.Controls.Add(this.lock_22);
            this.Controls.Add(this.lock_21);
            this.Controls.Add(this.lock_20);
            this.Controls.Add(this.lock_19);
            this.Controls.Add(this.lock_18);
            this.Controls.Add(this.lock_17);
            this.Controls.Add(this.lock_16);
            this.Controls.Add(this.lock_15);
            this.Controls.Add(this.lock_14);
            this.Controls.Add(this.lock_13);
            this.Controls.Add(this.lock_12);
            this.Controls.Add(this.lock_11);
            this.Controls.Add(this.lock_10);
            this.Controls.Add(this.lock_9);
            this.Controls.Add(this.lock_8);
            this.Controls.Add(this.lock_7);
            this.Controls.Add(this.lock_6);
            this.Controls.Add(this.lock_5);
            this.Controls.Add(this.lock_4);
            this.Controls.Add(this.lock_3);
            this.Controls.Add(this.lock_2);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.lock_1);
            this.Controls.Add(this.WhatTime);
            this.Name = "Locker";
            this.Text = "Locker";
            this.Load += new System.EventHandler(this.Locker_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox WhatTime;
        private System.Windows.Forms.Label lock_1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Label lock_2;
        private System.Windows.Forms.Label lock_3;
        private System.Windows.Forms.Label lock_4;
        private System.Windows.Forms.Label lock_5;
        private System.Windows.Forms.Label lock_10;
        private System.Windows.Forms.Label lock_9;
        private System.Windows.Forms.Label lock_8;
        private System.Windows.Forms.Label lock_7;
        private System.Windows.Forms.Label lock_6;
        private System.Windows.Forms.Label lock_15;
        private System.Windows.Forms.Label lock_14;
        private System.Windows.Forms.Label lock_13;
        private System.Windows.Forms.Label lock_12;
        private System.Windows.Forms.Label lock_11;
        private System.Windows.Forms.Label lock_20;
        private System.Windows.Forms.Label lock_19;
        private System.Windows.Forms.Label lock_18;
        private System.Windows.Forms.Label lock_17;
        private System.Windows.Forms.Label lock_16;
        private System.Windows.Forms.Label lock_30;
        private System.Windows.Forms.Label lock_29;
        private System.Windows.Forms.Label lock_28;
        private System.Windows.Forms.Label lock_27;
        private System.Windows.Forms.Label lock_26;
        private System.Windows.Forms.Label lock_25;
        private System.Windows.Forms.Label lock_24;
        private System.Windows.Forms.Label lock_23;
        private System.Windows.Forms.Label lock_22;
        private System.Windows.Forms.Label lock_21;
        private System.Windows.Forms.Label lock_40;
        private System.Windows.Forms.Label lock_39;
        private System.Windows.Forms.Label lock_38;
        private System.Windows.Forms.Label lock_37;
        private System.Windows.Forms.Label lock_36;
        private System.Windows.Forms.Label lock_35;
        private System.Windows.Forms.Label lock_34;
        private System.Windows.Forms.Label lock_33;
        private System.Windows.Forms.Label lock_32;
        private System.Windows.Forms.Label lock_31;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}