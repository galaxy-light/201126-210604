﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Managing_Car_Program
{
    class Player
    {
        public string Name { get; set; }
        public string Number { get; set; }
        public string Team { get; set; }
        public string Height { get; set; }
        public DateTime InsertTime { get; set; }
    }
}
