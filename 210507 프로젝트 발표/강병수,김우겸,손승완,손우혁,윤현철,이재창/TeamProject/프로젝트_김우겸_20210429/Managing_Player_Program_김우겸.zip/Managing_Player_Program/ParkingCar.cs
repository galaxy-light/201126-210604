﻿namespace Managing_Car_Program
{
    internal class ParkingCar
    {
    }
}