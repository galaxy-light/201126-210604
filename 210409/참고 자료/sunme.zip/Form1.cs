﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace sunme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Excel.Workbook wb = null;
        Excel.Worksheet ws = null;
        Excel.Application ap = null;

        
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (OpenFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    Console.WriteLine(OpenFileDialog1.FileName);
                    ap = new Excel.Application();
                    wb = ap.Workbooks.Open(OpenFileDialog1.FileName);
                    ws = wb.Sheets[1];
                    ap.Visible = false;
                    Range range = ws.UsedRange;
                    String data = "";
                    for (int i = 1; i <= range.Rows.Count; ++i)
                    {
                        for (int j = 1; j < range.Columns.Count; ++j)
                        {
                            if (range.Cells[i, j] != null && range.Cells[i, j].Value2 != null)
                            {
                                data += "위치 : " +i+" , "+ j +" > "+ ((range.Cells[i, j] as Range).Value2.ToString() + " ");
                            }
                            else
                            {
                                data += "위치 : " + i + " , " + j + " > "+"없음 ";
                            }
                            
                        }
                        data += "\n";
                    }
                    Console.WriteLine(data);

                    /*메모리 할당 해제*/
                    DeleteObject(range);
                    DeleteObject(ws);
                    DeleteObject(wb);
                    ap.Quit();
                    DeleteObject(ap);
                    /*메모리 할당 해제*/
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("에러" + ex.Message, "에러!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private void DeleteObject(object obj)
        {   // 메모리 해제를 위한 사용자 정의 함수
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("메모리 할당을 해제하는 중 문제가 발생하였습니다." + ex.ToString(), "경고!");
            }
            finally
            {
                GC.Collect();
            }
        }
    }
}
