﻿
namespace CSharpSecurity
{
    partial class UCKeySettingDepth
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblDepthDebugMsg = new System.Windows.Forms.Label();
            this.btnSubmitKeyDepth = new System.Windows.Forms.Button();
            this.txtbxKeyDepthInput = new ns1.BunifuMaterialTextbox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MD개성체", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(174)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(46, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(581, 56);
            this.label1.TabIndex = 2;
            this.label1.Text = "키깊이를 설정해주세요";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Hobo BT", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(174)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(35, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(185, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Key Depth Setting";
            // 
            // lblDepthDebugMsg
            // 
            this.lblDepthDebugMsg.AutoSize = true;
            this.lblDepthDebugMsg.Font = new System.Drawing.Font("MD개성체", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblDepthDebugMsg.Location = new System.Drawing.Point(35, 138);
            this.lblDepthDebugMsg.Name = "lblDepthDebugMsg";
            this.lblDepthDebugMsg.Size = new System.Drawing.Size(176, 28);
            this.lblDepthDebugMsg.TabIndex = 9;
            this.lblDepthDebugMsg.Text = "키깊이 1번째";
            // 
            // btnSubmitKeyDepth
            // 
            this.btnSubmitKeyDepth.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.btnSubmitKeyDepth.Font = new System.Drawing.Font("Hobo BT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitKeyDepth.ForeColor = System.Drawing.Color.White;
            this.btnSubmitKeyDepth.Location = new System.Drawing.Point(529, 309);
            this.btnSubmitKeyDepth.Name = "btnSubmitKeyDepth";
            this.btnSubmitKeyDepth.Size = new System.Drawing.Size(115, 47);
            this.btnSubmitKeyDepth.TabIndex = 10;
            this.btnSubmitKeyDepth.Text = "SUBMIT";
            this.btnSubmitKeyDepth.UseVisualStyleBackColor = false;
            this.btnSubmitKeyDepth.Click += new System.EventHandler(this.btnSubmitKeyDepth_Click);
            // 
            // txtbxKeyDepthInput
            // 
            this.txtbxKeyDepthInput.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbxKeyDepthInput.Font = new System.Drawing.Font("MD개성체", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtbxKeyDepthInput.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.txtbxKeyDepthInput.HintForeColor = System.Drawing.Color.Empty;
            this.txtbxKeyDepthInput.HintText = "";
            this.txtbxKeyDepthInput.isPassword = false;
            this.txtbxKeyDepthInput.LineFocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.txtbxKeyDepthInput.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.txtbxKeyDepthInput.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.txtbxKeyDepthInput.LineThickness = 3;
            this.txtbxKeyDepthInput.Location = new System.Drawing.Point(413, 309);
            this.txtbxKeyDepthInput.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtbxKeyDepthInput.Name = "txtbxKeyDepthInput";
            this.txtbxKeyDepthInput.Size = new System.Drawing.Size(92, 46);
            this.txtbxKeyDepthInput.TabIndex = 11;
            this.txtbxKeyDepthInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtbxKeyDepthInput.KeyUp += new System.Windows.Forms.KeyEventHandler(this.enterKeyUp);
            // 
            // UCKeySettingDepth
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtbxKeyDepthInput);
            this.Controls.Add(this.btnSubmitKeyDepth);
            this.Controls.Add(this.lblDepthDebugMsg);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "UCKeySettingDepth";
            this.Size = new System.Drawing.Size(675, 382);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblDepthDebugMsg;
        private System.Windows.Forms.Button btnSubmitKeyDepth;
        private ns1.BunifuMaterialTextbox txtbxKeyDepthInput;
    }
}
