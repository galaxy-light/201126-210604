﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpSecurity
{
    public partial class UCKeySettingLength : UserControl
    {
        public delegate void delEvent(object Sender, string strText); // delegate 선언
        public event delEvent eventKeySettingLength; // delegate event 선언

        public UCKeySettingLength()
        {
            InitializeComponent();
        }

        private void btnSubmitKeyLength_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtbxKeyLengthInput.Text, out mainForm.G_KEY_LENGTH))
            {
                lblLengthDebugMsg.Text = "잘못된 입력 !!";
                return;
            }
            else if(mainForm.G_KEY_LENGTH < 2)
            {
                lblLengthDebugMsg.Text = "키길이가 너무 짧아요. 2이상 입력 !!";
                return;
            }

            mainForm.G_KEY_DEPTH = new int[mainForm.G_KEY_LENGTH];
            mainForm.G_KEY_SORT = new int[mainForm.G_KEY_LENGTH];
            mainForm.initialize();

            lblLengthDebugMsg.Text = ">_< //";
            txtbxKeyLengthInput.Text = string.Empty;

            if (eventKeySettingLength != null)
            {
                eventKeySettingLength(this, string.Empty);
            }
        }

        private void enterKeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSubmitKeyLength_Click(sender, e);
            }
            return;
        }

    }
}
