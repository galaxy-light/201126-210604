﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpSecurity
{
    public partial class UCEncryption : UserControl
    {
        public delegate void delEvent(object Sender, string strText); // delegate 선언
        public event delEvent eventEncryption; // delegate event 선언

        public UCEncryption()
        {
            InitializeComponent();
        }

        private void btnSubmitNomalTxt_Click(object sender, EventArgs e)
        {
            int s = 0, i = 0, j = 0;

            // 주의!) C++에서 짠 거 그대로 옮기는 중... C#에서 문자열 끝에 널값을 쓰지 않아서 손보는 중 =ㅅ= 짜증나
            char[] str_input = (txtbxInputEnc.Text + "\0").ToCharArray();
            int str_input_length = str_input.Length - 1;

            // 암호화 후 길어지는 내용에 대하여 얼마나 길어지는지 계산 후 딱 그만큼의 크기의 배열 만들기 !!
            mainForm.G_STR_ARR = new char[
                (str_input_length / mainForm.G_BLOCK_ELEMENT_REAL_NUM) * mainForm.G_BLOCK_ELEMENT_NUM
                + ((str_input_length % mainForm.G_BLOCK_ELEMENT_REAL_NUM) == 0 ? 1 : mainForm.G_BLOCK_ELEMENT_NUM + 1)];

            /* 사각행렬 만드는 중 !! */
            int[] key_depth = new int[mainForm.G_KEY_LENGTH];
            mainForm.copy_key_depth_with_index_fix(key_depth);
            while (str_input[s] != '\0')
            {

                if (key_depth[j] < i % mainForm.G_KEY_MAX_DEPTH)
                {
                    mainForm.G_STR_ARR[(i * mainForm.G_KEY_LENGTH) + j] = mainForm.create_rnd_char(); // 의미없는 문자로 채워 넣기. 잘 안쓰는 x, y, z 같은 문자를 넣으면 좋다

                    j++;
                    if (j == mainForm.G_KEY_LENGTH) { j = 0; i++; }

                    continue;
                }

                mainForm.G_STR_ARR[(i * mainForm.G_KEY_LENGTH) + j] = str_input[s];

                j++;
                if (j == mainForm.G_KEY_LENGTH) { j = 0; i++; }

                s++;
            }
            mainForm.G_STR_ARR[(i * mainForm.G_KEY_LENGTH) + j] = str_input[s]; // 마지막 '\0' 문자 넣기

            int g_str_len;
            g_str_len = new String(mainForm.G_STR_ARR).IndexOf('\0');

            int padding; // 블록 암호이므로 마지막에 쓸 때 없는 값으로 padding 해야 할지도 모름
            padding = (mainForm.G_BLOCK_ELEMENT_NUM - (g_str_len % mainForm.G_BLOCK_ELEMENT_NUM)) % (mainForm.G_BLOCK_ELEMENT_NUM);
            // padding 적용 !!!
            for (int k = 0; k < padding; k++)
            {
                mainForm.G_STR_ARR[(i * mainForm.G_KEY_LENGTH) + j] = mainForm.create_rnd_char();
                j++;
                if (j == mainForm.G_KEY_LENGTH) { j = 0; i++; }
            }
            // "블록 암호이므로 마지막 블럭에서 padding한 갯수 : " + padding + "\n";
            mainForm.G_STR_ARR[(i * mainForm.G_KEY_LENGTH) + j] = '\0';

            // "암호화 후 평문 사이 사이에 끼어든 랜덤문자 확인 !!!\n-> ";
            // new string(mainForm.G_STR_ARR) + "\n";

            /* 이제 만들어낸 사각행렬의 각 열을 순서에 맞게 추출해내면 이것이 암호문이다!! */
            int block_num; // 사용자가 입력한 평문을 표현하는데 사용한 블럭의 수

            g_str_len = new String(mainForm.G_STR_ARR).IndexOf('\0');
            block_num = g_str_len / mainForm.G_BLOCK_ELEMENT_NUM;

            // "암호화에 사용된 블럭의 수 : " + block_num + "\n암호화 완료 !!!\n-> ";

            string str_tmp = "";
            for (i = 0; i < mainForm.G_KEY_LENGTH; i++)
            {
                for (j = 0; j < block_num * mainForm.G_KEY_MAX_DEPTH; j++)
                    str_tmp += mainForm.G_STR_ARR[(j * mainForm.G_KEY_LENGTH) + mainForm.G_KEY_SORT[i]];
            }

            // 암호화한 것을 곧장 해독해 볼 수 있도록 복호화 쪽으로 옮기기 위한 작업
            mainForm.G_PADDING = padding;
            mainForm.G_ENC_TEXT = str_tmp;

            if (eventEncryption != null)
            {
                eventEncryption(this, string.Empty);
            }
        }

        private void enterKeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSubmitNomalTxt_Click(sender, e);
            }
            return;
        }
    }
}
