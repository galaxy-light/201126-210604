﻿
namespace CSharpSecurity
{
    partial class mainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainForm));
            this.elipseMainForm = new ns1.BunifuElipse(this.components);
            this.dragCtrlMainForm = new ns1.BunifuDragControl(this.components);
            this.dragCtrlPanelMenu = new ns1.BunifuDragControl(this.components);
            this.panelMenu = new System.Windows.Forms.Panel();
            this.panelSide = new System.Windows.Forms.Panel();
            this.btnHelp = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.btnKeySetting = new System.Windows.Forms.Button();
            this.btnDecryption = new System.Windows.Forms.Button();
            this.btnEncryption = new System.Windows.Forms.Button();
            this.dragCtrlPanelNothingOne = new ns1.BunifuDragControl(this.components);
            this.panelNothingOne = new System.Windows.Forms.Panel();
            this.panelNothingTwo = new System.Windows.Forms.Panel();
            this.lblSymbolNameTwo = new System.Windows.Forms.Label();
            this.lblSymbolNameOne = new System.Windows.Forms.Label();
            this.pboxSymbol = new System.Windows.Forms.PictureBox();
            this.dragCtrlPanelNothingTwo = new ns1.BunifuDragControl(this.components);
            this.dragCtrlPboxSymbol = new ns1.BunifuDragControl(this.components);
            this.dragCtrlLblSymbolNameOne = new ns1.BunifuDragControl(this.components);
            this.dragCtrlLblSymbolNameTwo = new ns1.BunifuDragControl(this.components);
            this.elipsePanelNothingTwo = new ns1.BunifuElipse(this.components);
            this.lblBelong = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.dragCtrlLblBelong = new ns1.BunifuDragControl(this.components);
            this.ucKeySettingShowKey1 = new CSharpSecurity.UCKeySettingShowKey();
            this.ucKeySettingDepth1 = new CSharpSecurity.UCKeySettingDepth();
            this.ucKeySettingLength1 = new CSharpSecurity.UCKeySettingLength();
            this.ucDecryptionResult1 = new CSharpSecurity.UCDecryptionResult();
            this.ucDecryption1 = new CSharpSecurity.UCDecryption();
            this.ucEncryptionResult1 = new CSharpSecurity.UCEncryptionResult();
            this.ucEncryption1 = new CSharpSecurity.UCEncryption();
            this.ucHome1 = new CSharpSecurity.UCHome();
            this.panelMenu.SuspendLayout();
            this.panelNothingTwo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pboxSymbol)).BeginInit();
            this.SuspendLayout();
            // 
            // elipseMainForm
            // 
            this.elipseMainForm.ElipseRadius = 50;
            this.elipseMainForm.TargetControl = this;
            // 
            // dragCtrlMainForm
            // 
            this.dragCtrlMainForm.Fixed = true;
            this.dragCtrlMainForm.Horizontal = true;
            this.dragCtrlMainForm.TargetControl = this;
            this.dragCtrlMainForm.Vertical = true;
            // 
            // dragCtrlPanelMenu
            // 
            this.dragCtrlPanelMenu.Fixed = true;
            this.dragCtrlPanelMenu.Horizontal = true;
            this.dragCtrlPanelMenu.TargetControl = this.panelMenu;
            this.dragCtrlPanelMenu.Vertical = true;
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.panelMenu.Controls.Add(this.panelSide);
            this.panelMenu.Controls.Add(this.btnHelp);
            this.panelMenu.Controls.Add(this.btnHome);
            this.panelMenu.Controls.Add(this.btnKeySetting);
            this.panelMenu.Controls.Add(this.btnDecryption);
            this.panelMenu.Controls.Add(this.btnEncryption);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(200, 545);
            this.panelMenu.TabIndex = 4;
            // 
            // panelSide
            // 
            this.panelSide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.panelSide.Location = new System.Drawing.Point(12, 83);
            this.panelSide.Name = "panelSide";
            this.panelSide.Size = new System.Drawing.Size(10, 63);
            this.panelSide.TabIndex = 6;
            // 
            // btnHelp
            // 
            this.btnHelp.FlatAppearance.BorderSize = 0;
            this.btnHelp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHelp.Image = ((System.Drawing.Image)(resources.GetObject("btnHelp.Image")));
            this.btnHelp.Location = new System.Drawing.Point(43, 483);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(25, 25);
            this.btnHelp.TabIndex = 6;
            this.btnHelp.UseVisualStyleBackColor = true;
            this.btnHelp.Click += new System.EventHandler(this.btnHelp_Click);
            // 
            // btnHome
            // 
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("Hobo BT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ForeColor = System.Drawing.Color.White;
            this.btnHome.Image = ((System.Drawing.Image)(resources.GetObject("btnHome.Image")));
            this.btnHome.Location = new System.Drawing.Point(30, 83);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(170, 63);
            this.btnHome.TabIndex = 10;
            this.btnHome.Text = "    Home         ";
            this.btnHome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // btnKeySetting
            // 
            this.btnKeySetting.FlatAppearance.BorderSize = 0;
            this.btnKeySetting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKeySetting.Font = new System.Drawing.Font("Hobo BT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKeySetting.ForeColor = System.Drawing.Color.White;
            this.btnKeySetting.Image = ((System.Drawing.Image)(resources.GetObject("btnKeySetting.Image")));
            this.btnKeySetting.Location = new System.Drawing.Point(27, 323);
            this.btnKeySetting.Name = "btnKeySetting";
            this.btnKeySetting.Size = new System.Drawing.Size(170, 63);
            this.btnKeySetting.TabIndex = 9;
            this.btnKeySetting.Text = "    Key Setting";
            this.btnKeySetting.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnKeySetting.UseVisualStyleBackColor = true;
            this.btnKeySetting.Click += new System.EventHandler(this.btnKeySetting_Click);
            // 
            // btnDecryption
            // 
            this.btnDecryption.FlatAppearance.BorderSize = 0;
            this.btnDecryption.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDecryption.Font = new System.Drawing.Font("Hobo BT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDecryption.ForeColor = System.Drawing.Color.White;
            this.btnDecryption.Image = ((System.Drawing.Image)(resources.GetObject("btnDecryption.Image")));
            this.btnDecryption.Location = new System.Drawing.Point(27, 243);
            this.btnDecryption.Name = "btnDecryption";
            this.btnDecryption.Size = new System.Drawing.Size(170, 63);
            this.btnDecryption.TabIndex = 8;
            this.btnDecryption.Text = "    Decryption ";
            this.btnDecryption.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDecryption.UseVisualStyleBackColor = true;
            this.btnDecryption.Click += new System.EventHandler(this.btnDecryption_Click);
            // 
            // btnEncryption
            // 
            this.btnEncryption.FlatAppearance.BorderSize = 0;
            this.btnEncryption.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEncryption.Font = new System.Drawing.Font("Hobo BT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEncryption.ForeColor = System.Drawing.Color.White;
            this.btnEncryption.Image = ((System.Drawing.Image)(resources.GetObject("btnEncryption.Image")));
            this.btnEncryption.Location = new System.Drawing.Point(27, 163);
            this.btnEncryption.Name = "btnEncryption";
            this.btnEncryption.Size = new System.Drawing.Size(170, 63);
            this.btnEncryption.TabIndex = 7;
            this.btnEncryption.Text = "    Encryption ";
            this.btnEncryption.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnEncryption.UseVisualStyleBackColor = true;
            this.btnEncryption.Click += new System.EventHandler(this.btnEncryption_Click);
            // 
            // dragCtrlPanelNothingOne
            // 
            this.dragCtrlPanelNothingOne.Fixed = true;
            this.dragCtrlPanelNothingOne.Horizontal = true;
            this.dragCtrlPanelNothingOne.TargetControl = this.panelNothingOne;
            this.dragCtrlPanelNothingOne.Vertical = true;
            // 
            // panelNothingOne
            // 
            this.panelNothingOne.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.panelNothingOne.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelNothingOne.Location = new System.Drawing.Point(200, 0);
            this.panelNothingOne.Name = "panelNothingOne";
            this.panelNothingOne.Size = new System.Drawing.Size(675, 10);
            this.panelNothingOne.TabIndex = 5;
            // 
            // panelNothingTwo
            // 
            this.panelNothingTwo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.panelNothingTwo.Controls.Add(this.lblSymbolNameTwo);
            this.panelNothingTwo.Controls.Add(this.lblSymbolNameOne);
            this.panelNothingTwo.Controls.Add(this.pboxSymbol);
            this.panelNothingTwo.Location = new System.Drawing.Point(226, 2);
            this.panelNothingTwo.Name = "panelNothingTwo";
            this.panelNothingTwo.Size = new System.Drawing.Size(129, 138);
            this.panelNothingTwo.TabIndex = 2;
            // 
            // lblSymbolNameTwo
            // 
            this.lblSymbolNameTwo.AutoSize = true;
            this.lblSymbolNameTwo.Font = new System.Drawing.Font("Hobo BT", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSymbolNameTwo.ForeColor = System.Drawing.Color.White;
            this.lblSymbolNameTwo.Location = new System.Drawing.Point(59, 108);
            this.lblSymbolNameTwo.Name = "lblSymbolNameTwo";
            this.lblSymbolNameTwo.Size = new System.Drawing.Size(67, 20);
            this.lblSymbolNameTwo.TabIndex = 4;
            this.lblSymbolNameTwo.Text = "Security";
            // 
            // lblSymbolNameOne
            // 
            this.lblSymbolNameOne.AutoSize = true;
            this.lblSymbolNameOne.Font = new System.Drawing.Font("Hobo BT", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSymbolNameOne.ForeColor = System.Drawing.Color.White;
            this.lblSymbolNameOne.Location = new System.Drawing.Point(4, 86);
            this.lblSymbolNameOne.Name = "lblSymbolNameOne";
            this.lblSymbolNameOne.Size = new System.Drawing.Size(122, 22);
            this.lblSymbolNameOne.TabIndex = 3;
            this.lblSymbolNameOne.Text = "New! EncDec";
            // 
            // pboxSymbol
            // 
            this.pboxSymbol.Image = ((System.Drawing.Image)(resources.GetObject("pboxSymbol.Image")));
            this.pboxSymbol.Location = new System.Drawing.Point(35, 10);
            this.pboxSymbol.Name = "pboxSymbol";
            this.pboxSymbol.Size = new System.Drawing.Size(60, 60);
            this.pboxSymbol.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pboxSymbol.TabIndex = 0;
            this.pboxSymbol.TabStop = false;
            // 
            // dragCtrlPanelNothingTwo
            // 
            this.dragCtrlPanelNothingTwo.Fixed = true;
            this.dragCtrlPanelNothingTwo.Horizontal = true;
            this.dragCtrlPanelNothingTwo.TargetControl = this.panelNothingTwo;
            this.dragCtrlPanelNothingTwo.Vertical = true;
            // 
            // dragCtrlPboxSymbol
            // 
            this.dragCtrlPboxSymbol.Fixed = true;
            this.dragCtrlPboxSymbol.Horizontal = true;
            this.dragCtrlPboxSymbol.TargetControl = this.pboxSymbol;
            this.dragCtrlPboxSymbol.Vertical = true;
            // 
            // dragCtrlLblSymbolNameOne
            // 
            this.dragCtrlLblSymbolNameOne.Fixed = true;
            this.dragCtrlLblSymbolNameOne.Horizontal = true;
            this.dragCtrlLblSymbolNameOne.TargetControl = this.lblSymbolNameOne;
            this.dragCtrlLblSymbolNameOne.Vertical = true;
            // 
            // dragCtrlLblSymbolNameTwo
            // 
            this.dragCtrlLblSymbolNameTwo.Fixed = true;
            this.dragCtrlLblSymbolNameTwo.Horizontal = true;
            this.dragCtrlLblSymbolNameTwo.TargetControl = this.lblSymbolNameTwo;
            this.dragCtrlLblSymbolNameTwo.Vertical = true;
            // 
            // elipsePanelNothingTwo
            // 
            this.elipsePanelNothingTwo.ElipseRadius = 15;
            this.elipsePanelNothingTwo.TargetControl = this.panelNothingTwo;
            // 
            // lblBelong
            // 
            this.lblBelong.AutoSize = true;
            this.lblBelong.Font = new System.Drawing.Font("MD개성체", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblBelong.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.lblBelong.Location = new System.Drawing.Point(361, 24);
            this.lblBelong.Name = "lblBelong";
            this.lblBelong.Size = new System.Drawing.Size(386, 16);
            this.lblBelong.TabIndex = 6;
            this.lblBelong.Text = "(디지털컨버전스) 통합 응용 SW 개발자 (C#, JAVA)";
            // 
            // btnClose
            // 
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Hobo BT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(803, 16);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(35, 35);
            this.btnClose.TabIndex = 11;
            this.btnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // dragCtrlLblBelong
            // 
            this.dragCtrlLblBelong.Fixed = true;
            this.dragCtrlLblBelong.Horizontal = true;
            this.dragCtrlLblBelong.TargetControl = this.lblBelong;
            this.dragCtrlLblBelong.Vertical = true;
            // 
            // ucKeySettingShowKey1
            // 
            this.ucKeySettingShowKey1.Location = new System.Drawing.Point(200, 163);
            this.ucKeySettingShowKey1.Name = "ucKeySettingShowKey1";
            this.ucKeySettingShowKey1.Size = new System.Drawing.Size(675, 382);
            this.ucKeySettingShowKey1.TabIndex = 19;
            // 
            // ucKeySettingDepth1
            // 
            this.ucKeySettingDepth1.Location = new System.Drawing.Point(200, 163);
            this.ucKeySettingDepth1.Name = "ucKeySettingDepth1";
            this.ucKeySettingDepth1.Size = new System.Drawing.Size(675, 382);
            this.ucKeySettingDepth1.TabIndex = 18;
            // 
            // ucKeySettingLength1
            // 
            this.ucKeySettingLength1.Location = new System.Drawing.Point(200, 163);
            this.ucKeySettingLength1.Name = "ucKeySettingLength1";
            this.ucKeySettingLength1.Size = new System.Drawing.Size(675, 382);
            this.ucKeySettingLength1.TabIndex = 17;
            // 
            // ucDecryptionResult1
            // 
            this.ucDecryptionResult1.Location = new System.Drawing.Point(200, 163);
            this.ucDecryptionResult1.Name = "ucDecryptionResult1";
            this.ucDecryptionResult1.Size = new System.Drawing.Size(675, 382);
            this.ucDecryptionResult1.TabIndex = 16;
            // 
            // ucDecryption1
            // 
            this.ucDecryption1.Location = new System.Drawing.Point(200, 163);
            this.ucDecryption1.Name = "ucDecryption1";
            this.ucDecryption1.Size = new System.Drawing.Size(675, 382);
            this.ucDecryption1.TabIndex = 15;
            // 
            // ucEncryptionResult1
            // 
            this.ucEncryptionResult1.Location = new System.Drawing.Point(200, 163);
            this.ucEncryptionResult1.Name = "ucEncryptionResult1";
            this.ucEncryptionResult1.Size = new System.Drawing.Size(675, 382);
            this.ucEncryptionResult1.TabIndex = 14;
            // 
            // ucEncryption1
            // 
            this.ucEncryption1.Location = new System.Drawing.Point(200, 163);
            this.ucEncryption1.Name = "ucEncryption1";
            this.ucEncryption1.Size = new System.Drawing.Size(675, 382);
            this.ucEncryption1.TabIndex = 13;
            // 
            // ucHome1
            // 
            this.ucHome1.Location = new System.Drawing.Point(200, 163);
            this.ucHome1.Name = "ucHome1";
            this.ucHome1.Size = new System.Drawing.Size(675, 382);
            this.ucHome1.TabIndex = 12;
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(875, 545);
            this.Controls.Add(this.ucKeySettingShowKey1);
            this.Controls.Add(this.ucKeySettingDepth1);
            this.Controls.Add(this.ucKeySettingLength1);
            this.Controls.Add(this.ucDecryptionResult1);
            this.Controls.Add(this.ucDecryption1);
            this.Controls.Add(this.ucEncryptionResult1);
            this.Controls.Add(this.ucEncryption1);
            this.Controls.Add(this.ucHome1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblBelong);
            this.Controls.Add(this.panelNothingOne);
            this.Controls.Add(this.panelMenu);
            this.Controls.Add(this.panelNothingTwo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "mainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panelMenu.ResumeLayout(false);
            this.panelNothingTwo.ResumeLayout(false);
            this.panelNothingTwo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pboxSymbol)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ns1.BunifuElipse elipseMainForm;
        private ns1.BunifuDragControl dragCtrlMainForm;
        private ns1.BunifuDragControl dragCtrlPanelMenu;
        private ns1.BunifuDragControl dragCtrlPanelNothingOne;
        private System.Windows.Forms.Panel panelNothingTwo;
        private ns1.BunifuDragControl dragCtrlPanelNothingTwo;
        private System.Windows.Forms.Label lblSymbolNameOne;
        private System.Windows.Forms.PictureBox pboxSymbol;
        private ns1.BunifuDragControl dragCtrlPboxSymbol;
        private ns1.BunifuDragControl dragCtrlLblSymbolNameOne;
        private System.Windows.Forms.Label lblSymbolNameTwo;
        private ns1.BunifuDragControl dragCtrlLblSymbolNameTwo;
        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Panel panelNothingOne;
        private System.Windows.Forms.Button btnKeySetting;
        private System.Windows.Forms.Button btnDecryption;
        private System.Windows.Forms.Button btnEncryption;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Button btnHelp;
        private System.Windows.Forms.Panel panelSide;
        private ns1.BunifuElipse elipsePanelNothingTwo;
        private System.Windows.Forms.Label lblBelong;
        private System.Windows.Forms.Button btnClose;
        private ns1.BunifuDragControl dragCtrlLblBelong;
        private UCHome ucHome1;
        private UCKeySettingShowKey ucKeySettingShowKey1;
        private UCKeySettingDepth ucKeySettingDepth1;
        private UCKeySettingLength ucKeySettingLength1;
        private UCDecryptionResult ucDecryptionResult1;
        private UCDecryption ucDecryption1;
        private UCEncryptionResult ucEncryptionResult1;
        private UCEncryption ucEncryption1;
    }
}

