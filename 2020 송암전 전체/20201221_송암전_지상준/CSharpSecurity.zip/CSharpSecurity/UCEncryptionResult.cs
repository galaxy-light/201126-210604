﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpSecurity
{
    public partial class UCEncryptionResult : UserControl
    {
        public delegate void delEvent(object Sender, string strText); // delegate 선언
        public event delEvent eventEncryptionResult; // delegate event 선언

        public UCEncryptionResult()
        {
            InitializeComponent();

            mainForm.eventMainForm += eventMainForm;
        }

        private void btnBackEnc_Click(object sender, EventArgs e)
        {
            txtbxResultEnc.Text = string.Empty;

            if (eventEncryptionResult != null)
            {
                eventEncryptionResult(this, string.Empty);
            }
        }

        private void eventMainForm(object Sender, string strText)
        {
            txtbxResultEnc.Text = mainForm.G_ENC_TEXT;
            lblPaddingInfoNum.Text = mainForm.G_PADDING + "";
            return;
        }

    }
}
