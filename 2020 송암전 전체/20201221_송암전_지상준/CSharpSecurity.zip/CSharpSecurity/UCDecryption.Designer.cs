﻿
namespace CSharpSecurity
{
    partial class UCDecryption
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtbxInputDec = new System.Windows.Forms.RichTextBox();
            this.elipseTxtbxInputDec = new ns1.BunifuElipse(this.components);
            this.lblPaddingNotice = new System.Windows.Forms.Label();
            this.txtbxPaddingNum = new ns1.BunifuMaterialTextbox();
            this.btnSubmitEncTxtAndPdNum = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtbxInputDec
            // 
            this.txtbxInputDec.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.txtbxInputDec.Font = new System.Drawing.Font("MD개성체", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtbxInputDec.ForeColor = System.Drawing.Color.Gainsboro;
            this.txtbxInputDec.Location = new System.Drawing.Point(32, 21);
            this.txtbxInputDec.Name = "txtbxInputDec";
            this.txtbxInputDec.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.txtbxInputDec.Size = new System.Drawing.Size(612, 265);
            this.txtbxInputDec.TabIndex = 2;
            this.txtbxInputDec.Text = "Hello World !!!!!!!!";
            this.txtbxInputDec.KeyUp += new System.Windows.Forms.KeyEventHandler(this.enterKeyUp);
            // 
            // elipseTxtbxInputDec
            // 
            this.elipseTxtbxInputDec.ElipseRadius = 20;
            this.elipseTxtbxInputDec.TargetControl = this.txtbxInputDec;
            // 
            // lblPaddingNotice
            // 
            this.lblPaddingNotice.AutoSize = true;
            this.lblPaddingNotice.Font = new System.Drawing.Font("MD개성체", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblPaddingNotice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.lblPaddingNotice.Location = new System.Drawing.Point(207, 320);
            this.lblPaddingNotice.Name = "lblPaddingNotice";
            this.lblPaddingNotice.Size = new System.Drawing.Size(191, 22);
            this.lblPaddingNotice.TabIndex = 4;
            this.lblPaddingNotice.Text = "Padding 된 문자수";
            // 
            // txtbxPaddingNum
            // 
            this.txtbxPaddingNum.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbxPaddingNum.Font = new System.Drawing.Font("MD개성체", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtbxPaddingNum.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.txtbxPaddingNum.HintForeColor = System.Drawing.Color.Empty;
            this.txtbxPaddingNum.HintText = "";
            this.txtbxPaddingNum.isPassword = false;
            this.txtbxPaddingNum.LineFocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.txtbxPaddingNum.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.txtbxPaddingNum.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.txtbxPaddingNum.LineThickness = 3;
            this.txtbxPaddingNum.Location = new System.Drawing.Point(413, 309);
            this.txtbxPaddingNum.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtbxPaddingNum.Name = "txtbxPaddingNum";
            this.txtbxPaddingNum.Size = new System.Drawing.Size(92, 46);
            this.txtbxPaddingNum.TabIndex = 5;
            this.txtbxPaddingNum.Text = "0";
            this.txtbxPaddingNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // btnSubmitEncTxtAndPdNum
            // 
            this.btnSubmitEncTxtAndPdNum.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.btnSubmitEncTxtAndPdNum.Font = new System.Drawing.Font("Hobo BT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitEncTxtAndPdNum.ForeColor = System.Drawing.Color.White;
            this.btnSubmitEncTxtAndPdNum.Location = new System.Drawing.Point(529, 309);
            this.btnSubmitEncTxtAndPdNum.Name = "btnSubmitEncTxtAndPdNum";
            this.btnSubmitEncTxtAndPdNum.Size = new System.Drawing.Size(115, 47);
            this.btnSubmitEncTxtAndPdNum.TabIndex = 6;
            this.btnSubmitEncTxtAndPdNum.Text = "SUBMIT";
            this.btnSubmitEncTxtAndPdNum.UseVisualStyleBackColor = false;
            this.btnSubmitEncTxtAndPdNum.Click += new System.EventHandler(this.btnSubmitEncTxtAndPdNum_Click);
            // 
            // UCDecryption
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnSubmitEncTxtAndPdNum);
            this.Controls.Add(this.txtbxPaddingNum);
            this.Controls.Add(this.lblPaddingNotice);
            this.Controls.Add(this.txtbxInputDec);
            this.Name = "UCDecryption";
            this.Size = new System.Drawing.Size(675, 382);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox txtbxInputDec;
        private ns1.BunifuElipse elipseTxtbxInputDec;
        private System.Windows.Forms.Label lblPaddingNotice;
        private ns1.BunifuMaterialTextbox txtbxPaddingNum;
        private System.Windows.Forms.Button btnSubmitEncTxtAndPdNum;
    }
}
