﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpSecurity
{
    public partial class UCDecryptionResult : UserControl
    {
        public delegate void delEvent(object Sender, string strText); // delegate 선언
        public event delEvent eventDecryptionResult; // delegate event 선언

        public UCDecryptionResult()
        {
            InitializeComponent();

            mainForm.eventMainForm += eventMainForm;
        }

        private void btnBackDec_Click(object sender, EventArgs e)
        {
            txtbxResultDec.Text = string.Empty;

            if (eventDecryptionResult != null)
            {
                eventDecryptionResult(this, string.Empty);
            }
        }

        private void eventMainForm(object Sender, string strText)
        {
            txtbxResultDec.Text = new string(mainForm.G_STR_CLEAR_TEXT);
            return;
        }

    }
}
