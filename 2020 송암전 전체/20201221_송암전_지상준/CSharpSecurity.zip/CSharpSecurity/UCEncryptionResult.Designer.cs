﻿
namespace CSharpSecurity
{
    partial class UCEncryptionResult
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtbxResultEnc = new System.Windows.Forms.RichTextBox();
            this.elipseTxtbxResultEnc = new ns1.BunifuElipse(this.components);
            this.btnBackEnc = new System.Windows.Forms.Button();
            this.lblPaddingInfo = new System.Windows.Forms.Label();
            this.lblPaddingInfoNum = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtbxResultEnc
            // 
            this.txtbxResultEnc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.txtbxResultEnc.Font = new System.Drawing.Font("MD개성체", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtbxResultEnc.ForeColor = System.Drawing.Color.Gainsboro;
            this.txtbxResultEnc.Location = new System.Drawing.Point(32, 21);
            this.txtbxResultEnc.Name = "txtbxResultEnc";
            this.txtbxResultEnc.ReadOnly = true;
            this.txtbxResultEnc.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.txtbxResultEnc.Size = new System.Drawing.Size(612, 265);
            this.txtbxResultEnc.TabIndex = 1;
            this.txtbxResultEnc.Text = "";
            // 
            // elipseTxtbxResultEnc
            // 
            this.elipseTxtbxResultEnc.ElipseRadius = 20;
            this.elipseTxtbxResultEnc.TargetControl = this.txtbxResultEnc;
            // 
            // btnBackEnc
            // 
            this.btnBackEnc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.btnBackEnc.Font = new System.Drawing.Font("Hobo BT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackEnc.ForeColor = System.Drawing.Color.White;
            this.btnBackEnc.Location = new System.Drawing.Point(529, 309);
            this.btnBackEnc.Name = "btnBackEnc";
            this.btnBackEnc.Size = new System.Drawing.Size(115, 47);
            this.btnBackEnc.TabIndex = 2;
            this.btnBackEnc.Text = "BACK";
            this.btnBackEnc.UseVisualStyleBackColor = false;
            this.btnBackEnc.Click += new System.EventHandler(this.btnBackEnc_Click);
            // 
            // lblPaddingInfo
            // 
            this.lblPaddingInfo.AutoSize = true;
            this.lblPaddingInfo.Font = new System.Drawing.Font("MD개성체", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblPaddingInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.lblPaddingInfo.Location = new System.Drawing.Point(28, 320);
            this.lblPaddingInfo.Name = "lblPaddingInfo";
            this.lblPaddingInfo.Size = new System.Drawing.Size(191, 22);
            this.lblPaddingInfo.TabIndex = 3;
            this.lblPaddingInfo.Text = "Padding 된 문자수";
            // 
            // lblPaddingInfoNum
            // 
            this.lblPaddingInfoNum.AutoSize = true;
            this.lblPaddingInfoNum.Font = new System.Drawing.Font("MD개성체", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblPaddingInfoNum.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.lblPaddingInfoNum.Location = new System.Drawing.Point(247, 320);
            this.lblPaddingInfoNum.Name = "lblPaddingInfoNum";
            this.lblPaddingInfoNum.Size = new System.Drawing.Size(53, 22);
            this.lblPaddingInfoNum.TabIndex = 4;
            this.lblPaddingInfoNum.Text = "0 개";
            // 
            // UCEncryptionResult
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblPaddingInfoNum);
            this.Controls.Add(this.lblPaddingInfo);
            this.Controls.Add(this.btnBackEnc);
            this.Controls.Add(this.txtbxResultEnc);
            this.Name = "UCEncryptionResult";
            this.Size = new System.Drawing.Size(675, 382);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox txtbxResultEnc;
        private ns1.BunifuElipse elipseTxtbxResultEnc;
        private System.Windows.Forms.Button btnBackEnc;
        private System.Windows.Forms.Label lblPaddingInfo;
        private System.Windows.Forms.Label lblPaddingInfoNum;
    }
}
