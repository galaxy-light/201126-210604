﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpSecurity
{
    public partial class UCKeySettingShowKey : UserControl
    {
        public delegate void delEvent(object Sender, string strText); // delegate 선언
        public event delEvent eventKeySettingShowKey; // delegate event 선언

        public UCKeySettingShowKey()
        {
            InitializeComponent();
            lblShowKeyDebugMsg.Text = $"키설정 완료 !!";
        }

        private void btnKeyReset_Click(object sender, EventArgs e)
        {
            mainForm.isKeySet = false;

            if (eventKeySettingShowKey != null)
            {
                eventKeySettingShowKey(this, string.Empty);
            }
        }
    }
}
