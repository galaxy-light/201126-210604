﻿
namespace CSharpSecurity
{
    partial class UCDecryptionResult
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtbxResultDec = new System.Windows.Forms.RichTextBox();
            this.elipseTxtbxResultDec = new ns1.BunifuElipse(this.components);
            this.btnBackDec = new System.Windows.Forms.Button();
            this.lblNoticeEncResult = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtbxResultDec
            // 
            this.txtbxResultDec.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.txtbxResultDec.Font = new System.Drawing.Font("MD개성체", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtbxResultDec.ForeColor = System.Drawing.Color.Gainsboro;
            this.txtbxResultDec.Location = new System.Drawing.Point(32, 21);
            this.txtbxResultDec.Name = "txtbxResultDec";
            this.txtbxResultDec.ReadOnly = true;
            this.txtbxResultDec.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.txtbxResultDec.Size = new System.Drawing.Size(612, 265);
            this.txtbxResultDec.TabIndex = 2;
            this.txtbxResultDec.Text = "";
            // 
            // elipseTxtbxResultDec
            // 
            this.elipseTxtbxResultDec.ElipseRadius = 20;
            this.elipseTxtbxResultDec.TargetControl = this.txtbxResultDec;
            // 
            // btnBackDec
            // 
            this.btnBackDec.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.btnBackDec.Font = new System.Drawing.Font("Hobo BT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackDec.ForeColor = System.Drawing.Color.White;
            this.btnBackDec.Location = new System.Drawing.Point(529, 309);
            this.btnBackDec.Name = "btnBackDec";
            this.btnBackDec.Size = new System.Drawing.Size(115, 47);
            this.btnBackDec.TabIndex = 3;
            this.btnBackDec.Text = "BACK";
            this.btnBackDec.UseVisualStyleBackColor = false;
            this.btnBackDec.Click += new System.EventHandler(this.btnBackDec_Click);
            // 
            // lblNoticeEncResult
            // 
            this.lblNoticeEncResult.AutoSize = true;
            this.lblNoticeEncResult.Font = new System.Drawing.Font("MD개성체", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblNoticeEncResult.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.lblNoticeEncResult.Location = new System.Drawing.Point(28, 320);
            this.lblNoticeEncResult.Name = "lblNoticeEncResult";
            this.lblNoticeEncResult.Size = new System.Drawing.Size(206, 22);
            this.lblNoticeEncResult.TabIndex = 5;
            this.lblNoticeEncResult.Text = "평문 노출 ~!! >_<";
            // 
            // UCDecryptionResult
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblNoticeEncResult);
            this.Controls.Add(this.btnBackDec);
            this.Controls.Add(this.txtbxResultDec);
            this.Name = "UCDecryptionResult";
            this.Size = new System.Drawing.Size(675, 382);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox txtbxResultDec;
        private ns1.BunifuElipse elipseTxtbxResultDec;
        private System.Windows.Forms.Button btnBackDec;
        private System.Windows.Forms.Label lblNoticeEncResult;
    }
}
