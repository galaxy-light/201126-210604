﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpSecurity
{
    public partial class UCDecryption : UserControl
    {
        public delegate void delEvent(object Sender, string strText); // delegate 선언
        public event delEvent eventDecryption; // delegate event 선언

        public UCDecryption()
        {
            InitializeComponent();

            mainForm.eventMainForm += eventMainForm;
        }

        private void btnSubmitEncTxtAndPdNum_Click(object sender, EventArgs e)
        {
            int padding_tmp = 0;
            if(!int.TryParse(txtbxPaddingNum.Text, out padding_tmp))
            {
                txtbxInputDec.Text = "Padding 값이 잘못되었습니다";
                return;
            }
            else if (padding_tmp < 0)
            {
                txtbxInputDec.Text = "Padding 값은 양수 혹은 0인 정수입니다";
                return;
            }
            mainForm.G_PADDING = padding_tmp;



            int s = 0, t = 0, i = 0, j = 0;

            // 주의!) C++에서 짠 거 그대로 옮기는 중... C#에서 문자열 끝에 널값을 쓰지 않아서 손보는 중 =ㅅ= 짜증나
            string str_input_tmp = txtbxInputDec.Text;
            int str_input_length = str_input_tmp.Length;
            /* 블럭 단위로 들어오기를 기대한다. */
            if ((str_input_length % mainForm.G_BLOCK_ELEMENT_NUM) != 0)
            {
                // 현재 주어진 키에 맞게 block 단위로 길이 맞추기
                int padding = mainForm.G_BLOCK_ELEMENT_NUM - (str_input_length % mainForm.G_BLOCK_ELEMENT_NUM);
                for (int z = 0; z < padding; z++)
                    str_input_tmp += "_";
                    // "현재 주어진 키의 블록 단위가 아닙니다. 임으로 블록단위로 맞추겠습니다.\n" +
                    // "평문이 노출되지만 문장 끝부분에 의미없는 것이 붙어 나올 수 있습니다.\n" +
                    // "padding한 수 : " + padding + "\n";
            }
            str_input_tmp += '\0';
            char[] str_input = str_input_tmp.ToCharArray();
            str_input_length = str_input.Length - 1;

            int block_num; // 사용자가 입력한 암호문을 표현하는데 사용한 블럭의 수
            block_num = str_input_length / mainForm.G_BLOCK_ELEMENT_NUM;
            // "암호화에 사용된 블럭의 수 : " + block_num + "\n";
            // G_STR -> 사각행렬에 들어가는 모든 요소만큼 크기를 잡는다
            mainForm.G_STR_ARR = new char[block_num * mainForm.G_BLOCK_ELEMENT_NUM + 1];
            /* 사각행렬 순서에 맞게 복원 중 !! */
            for (i = 0; i < mainForm.G_KEY_LENGTH; i++)
            {
                for (j = 0; j < block_num * mainForm.G_KEY_MAX_DEPTH; j++, s++)
                    mainForm.G_STR_ARR[(j * mainForm.G_KEY_LENGTH) + mainForm.G_KEY_SORT[i]] = str_input[s];
            }
            mainForm.G_STR_ARR[str_input_length] = '\0';

            // "키의 순서에 맞게 사각 행렬을 복원 후 간단한 확인 !!!\n-> " + new string(mainForm.G_STR_ARR) + "\n";
            // "-> 평문이 노출되기 시작했으나 아직 완전하지는 않은 것을 확인 !!\n";

            /* 평문에 삽입된 의미 없는 문자를 걷어내는 작업, 키의 깊이 만큼만 읽어서 뿌려준다 */
            int[] Key_Depth_Temp = new int[mainForm.G_KEY_LENGTH];
            mainForm.copy_key_depth_with_index_fix(Key_Depth_Temp);
            // TODO : G_STR_CLEAR_TEXT에 복호화된 평문을 저장할만큼 크기를 지정한다
            mainForm.G_STR_CLEAR_TEXT = new char[block_num * mainForm.G_BLOCK_ELEMENT_REAL_NUM + 1];
            // 평문 사이사이에 끼어 있는 의미 없는 문자를 제거한다 !!
            i = 0; j = 0; s = 0; t = 0;
            int p_start = 0; // 사용자가 패딩되었다는 수 만큼 덜 읽어 드립니당 ~!! >_<
            int p_end = (block_num * mainForm.G_BLOCK_ELEMENT_NUM) - mainForm.G_PADDING;
            while (mainForm.G_STR_ARR[s] != '\0')
            {
                if (p_end == p_start++)
                    break;

                if (Key_Depth_Temp[j] < i % mainForm.G_KEY_MAX_DEPTH)
                { //출력 안 함
                    s++;

                    j++;
                    if (j == mainForm.G_KEY_LENGTH) { j = 0; i++; }

                    continue;
                }

                mainForm.G_STR_CLEAR_TEXT[t] = mainForm.G_STR_ARR[s];

                s++;
                t++;

                j++;
                if (j == mainForm.G_KEY_LENGTH) { j = 0; i++; }
            }
            mainForm.G_STR_CLEAR_TEXT[t] = '\0';
            // "\n-> 평문이 노출^^!!" + new String(mainForm.G_STR_CLEAR_TEXT);


            if (eventDecryption != null)
            {
                eventDecryption(this, string.Empty);
            }
        }

        private void enterKeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSubmitEncTxtAndPdNum_Click(sender, e);
            }
            return;
        }

        private void eventMainForm(object Sender, string strText)
        {
            txtbxInputDec.Text = mainForm.G_ENC_TEXT;
            txtbxPaddingNum.Text = mainForm.G_PADDING + "";
            return;
        }
    }
}
