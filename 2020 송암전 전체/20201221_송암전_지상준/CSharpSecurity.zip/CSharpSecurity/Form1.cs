﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpSecurity
{
    public partial class mainForm : Form
    {
        public delegate void delEvent(object Sender, string strText); // delegate 선언
        public static event delEvent eventMainForm; // delegate event 선언

        // Global Variables
        public static int G_KEY_LENGTH; // Key의 길이
        public static int[] G_KEY_DEPTH; // 배열의 각각의 인덱스가 Key의 숫자 하나하나에 대응된다. 그리고 이는 곧 사각행렬에서 열의 깊이를 뜻한다.
        public static int[] G_KEY_SORT; // 열을 추출하여 나열할 때 이용한다.
        public static char[] G_STR_ARR; // 평문을 암호화하거나, 암호문을 평문으로 변환할 때 만든 사각행렬의 정보
        public static char[] G_STR_CLEAR_TEXT; // 암호화된 문장을 평문으로 변환후 저장될 변수

        public static int G_KEY_MAX_DEPTH; // 키 깊이 중 가장 깊은 키
        public static int G_PADDING; // 패딩
        public static int G_INDEX_KEY_DEPTH; // 사용자가 키설정시에, 각각의 키 깊이를 순차적으로 지정 
        public static int G_BLOCK_ELEMENT_NUM; // 한 블럭에서 한 문자가 들어갈 수 있는 총량. X 포함
        public static int G_BLOCK_ELEMENT_REAL_NUM; // 한 블럭에서 한 문자가 들어갈 수 있는 X 미포함 실제적인 수

        public static readonly Random R = new Random();
        public static Boolean isKeySet = false;

        public static string G_ENC_TEXT = string.Empty;

        public mainForm()
        {
            InitializeComponent();
            panelSide.Height = btnHome.Height;
            panelSide.Top = btnHome.Top;
            ucHome1.BringToFront();

            ucKeySettingLength1.eventKeySettingLength += eventKeySettingLength;
            ucKeySettingDepth1.eventKeySettingDepth += eventKeySettingDepth;
            ucKeySettingShowKey1.eventKeySettingShowKey += eventKeySettingShowKey;
            ucEncryption1.eventEncryption += eventEncryption;
            ucEncryptionResult1.eventEncryptionResult += eventEncryptionResult;
            ucDecryption1.eventDecryption += eventDecryption;
            ucDecryptionResult1.eventDecryptionResult += eventDecryptionResult;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            panelSide.Height = btnHome.Height;
            panelSide.Top = btnHome.Top;
            ucHome1.BringToFront();
        }

        private void btnEncryption_Click(object sender, EventArgs e)
        {
            if (!isKeySet)
            {
                panelSide.Height = btnKeySetting.Height;
                panelSide.Top = btnKeySetting.Top;
                ucKeySettingLength1.BringToFront();
                return;
            }

            panelSide.Height = btnEncryption.Height;
            panelSide.Top = btnEncryption.Top;
            ucEncryption1.BringToFront();
        }

        private void btnDecryption_Click(object sender, EventArgs e)
        {
            if (!isKeySet)
            {
                panelSide.Height = btnKeySetting.Height;
                panelSide.Top = btnKeySetting.Top;
                ucKeySettingLength1.BringToFront();
                return;
            }

            panelSide.Height = btnDecryption.Height;
            panelSide.Top = btnDecryption.Top;
            ucDecryption1.BringToFront();
        }

        private void btnKeySetting_Click(object sender, EventArgs e)
        {
            panelSide.Height = btnKeySetting.Height;
            panelSide.Top = btnKeySetting.Top;
            if (isKeySet)
                ucKeySettingShowKey1.BringToFront();
            else
                ucKeySettingLength1.BringToFront();
        }






























        private void eventKeySettingLength(object Sender, string strText)
        {
            ucKeySettingDepth1.BringToFront();
            return;
        }

        private void eventKeySettingDepth(object Sender, string strText)
        {
            ucKeySettingShowKey1.BringToFront();
            return;
        }

        private void eventKeySettingShowKey(object Sender, string strText)
        {
            ucKeySettingLength1.BringToFront();
            return;
        }

        private void eventEncryption(object Sender, string strText)
        {
            if (eventMainForm != null)
            {
                eventMainForm(this, string.Empty);
            }
            ucEncryptionResult1.BringToFront();
            return;
        }

        private void eventEncryptionResult(object Sender, string strText)
        {
            ucEncryption1.BringToFront();
            return;
        }

        private void eventDecryption(object Sender, string strText)
        {
            if (eventMainForm != null)
            {
                eventMainForm(this, string.Empty);
            }
            ucDecryptionResult1.BringToFront();
            return;
        }

        private void eventDecryptionResult(object Sender, string strText)
        {
            ucDecryption1.BringToFront();
            return;
        }





        public static void initialize()
        {
            for (int i = 0; i < G_KEY_LENGTH; i++)
            {
                G_KEY_DEPTH[i] = 0;
                G_KEY_SORT[i] = 0;
            }
        }

        public static void copy_key_depth_with_index_fix(int[] key_depth_temp)
        {
            int i;
            for (i = 0; i < G_KEY_LENGTH; i++)
                key_depth_temp[i] = G_KEY_DEPTH[i] - 1; //인덱스 조절까지 해주는거 ~~
        }

        public static int get_key_max_depth()
        {
            int max = 0;

            for (int i = 0; i < G_KEY_LENGTH; i++)
            {
                if (max < G_KEY_DEPTH[i])
                    max = G_KEY_DEPTH[i];
            }

            return max;
        }

        public static void key_sort() // 내부적으로 버블정렬을 이용한다.
        {
            int i, j, tmp;

            int[] key_depth_temp = new int[G_KEY_LENGTH];
            copy_key_depth_with_index_fix(key_depth_temp);

            // 지역변수 Key_Depth_Temp에 우선 키 정렬(버블 정렬 이용)
            for (i = 0; i < G_KEY_LENGTH - 1; i++)
            {
                for (j = 0; j < (G_KEY_LENGTH - 1 - i); j++)
                {
                    if (key_depth_temp[j] > key_depth_temp[j + 1])
                    {
                        tmp = key_depth_temp[j];
                        key_depth_temp[j] = key_depth_temp[j + 1];
                        key_depth_temp[j + 1] = tmp;
                    }
                }
            }

            // Key_Depth_Temp를 전역변수 Key_Sort에 적용
            for (i = 0; i < G_KEY_LENGTH; i++)
                G_KEY_SORT[i] = key_depth_temp[i] + 1;

            // Key_Sort를 이제 Key_Depth의 인덱스로 바꿔주는 차례
            for (i = 0; i < G_KEY_LENGTH; i++)
            {
                for (j = 0; j < G_KEY_LENGTH; j++)
                {
                    if (G_KEY_SORT[i] == G_KEY_DEPTH[j])
                    {
                        G_KEY_SORT[i] = j; // Key_Depth의 깊이 값이 아닌 인덱스를 쓴다.
                        break;
                    }
                }
            }
        }

        public static char create_rnd_char()
        {
            char rnd_char = (char)R.Next(65, 122);
            return rnd_char;
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("사각행렬을 이용한 전치기법을 배우는 과정에서 아이디어가 생각이 났고,\n\n" +
                "이를 구현하였습니다");
        }
    }
}
