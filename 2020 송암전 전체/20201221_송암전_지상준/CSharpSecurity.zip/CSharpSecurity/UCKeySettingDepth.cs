﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpSecurity
{
    public partial class UCKeySettingDepth : UserControl
    {
        public delegate void delEvent(object Sender, string strText); // delegate 선언
        public event delEvent eventKeySettingDepth; // delegate event 선언

        public UCKeySettingDepth()
        {
            InitializeComponent();
        }

        private void btnSubmitKeyDepth_Click(object sender, EventArgs e)
        {
            int tmp;
            if (int.TryParse(txtbxKeyDepthInput.Text, out tmp))
            {
                if (tmp == 0)
                {
                    lblDepthDebugMsg.Text = "키깊이는 0일 수 없어요 !!";
                    txtbxKeyDepthInput.Text = "";
                    return;
                }
            }
            else
            {
                lblDepthDebugMsg.Text = "잘못된 입력 !!";
                txtbxKeyDepthInput.Text = "";
                return;
            }
            mainForm.G_KEY_DEPTH[mainForm.G_INDEX_KEY_DEPTH] = tmp;

            for (int i = 0; i < mainForm.G_KEY_LENGTH; i++)
            {
                if (mainForm.G_INDEX_KEY_DEPTH == i)
                    continue;
                if (mainForm.G_KEY_DEPTH[mainForm.G_INDEX_KEY_DEPTH] == mainForm.G_KEY_DEPTH[i])
                {
                    lblDepthDebugMsg.Text = "키깊이는 중복일 수 없어요 !!";
                    return;
                }
            }

            mainForm.G_INDEX_KEY_DEPTH++;
            lblDepthDebugMsg.Text = $"키깊이 {mainForm.G_INDEX_KEY_DEPTH + 1}번째";
            txtbxKeyDepthInput.Text = "";

            if (mainForm.G_INDEX_KEY_DEPTH == mainForm.G_KEY_LENGTH)
            {
                // Key 깊이 모두 설정 완료
                lblDepthDebugMsg.Text = "키깊이 1번째";

                mainForm.G_KEY_MAX_DEPTH = mainForm.get_key_max_depth();
                mainForm.G_BLOCK_ELEMENT_NUM = mainForm.G_KEY_MAX_DEPTH * mainForm.G_KEY_LENGTH; // 한 블럭에서 한 문자가 들어갈 수 있는 총량. X 포함
                mainForm.G_BLOCK_ELEMENT_REAL_NUM = 0; // 한 블럭에서 한 문자가 들어갈 수 있는 X 미포함 실제적인 수
                for (int z = 0; z < mainForm.G_KEY_LENGTH; z++)
                    mainForm.G_BLOCK_ELEMENT_REAL_NUM += mainForm.G_KEY_DEPTH[z];
                mainForm.G_KEY_MAX_DEPTH = mainForm.get_key_max_depth();
                mainForm.key_sort(); //Key_Sort[] 적용

                mainForm.G_INDEX_KEY_DEPTH = 0;
                mainForm.isKeySet = true;

                if (eventKeySettingDepth != null)
                {
                    eventKeySettingDepth(this, string.Empty);
                }
            }

        }

        private void enterKeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSubmitKeyDepth_Click(sender, e);
            }
            return;
        }

    }
}
