﻿
namespace CSharpSecurity
{
    partial class UCEncryption
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtbxInputEnc = new System.Windows.Forms.RichTextBox();
            this.elipseTxtbxInputEnc = new ns1.BunifuElipse(this.components);
            this.btnSubmitNomalTxt = new System.Windows.Forms.Button();
            this.lblNoticeDec = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtbxInputEnc
            // 
            this.txtbxInputEnc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.txtbxInputEnc.Font = new System.Drawing.Font("MD개성체", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtbxInputEnc.ForeColor = System.Drawing.Color.Gainsboro;
            this.txtbxInputEnc.Location = new System.Drawing.Point(32, 21);
            this.txtbxInputEnc.Name = "txtbxInputEnc";
            this.txtbxInputEnc.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.txtbxInputEnc.Size = new System.Drawing.Size(612, 265);
            this.txtbxInputEnc.TabIndex = 0;
            this.txtbxInputEnc.Text = "Hello World !!!!!!!!";
            this.txtbxInputEnc.KeyUp += new System.Windows.Forms.KeyEventHandler(this.enterKeyUp);
            // 
            // elipseTxtbxInputEnc
            // 
            this.elipseTxtbxInputEnc.ElipseRadius = 20;
            this.elipseTxtbxInputEnc.TargetControl = this.txtbxInputEnc;
            // 
            // btnSubmitNomalTxt
            // 
            this.btnSubmitNomalTxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.btnSubmitNomalTxt.Font = new System.Drawing.Font("Hobo BT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitNomalTxt.ForeColor = System.Drawing.Color.White;
            this.btnSubmitNomalTxt.Location = new System.Drawing.Point(529, 309);
            this.btnSubmitNomalTxt.Name = "btnSubmitNomalTxt";
            this.btnSubmitNomalTxt.Size = new System.Drawing.Size(115, 47);
            this.btnSubmitNomalTxt.TabIndex = 1;
            this.btnSubmitNomalTxt.Text = "SUBMIT";
            this.btnSubmitNomalTxt.UseVisualStyleBackColor = false;
            this.btnSubmitNomalTxt.Click += new System.EventHandler(this.btnSubmitNomalTxt_Click);
            // 
            // lblNoticeDec
            // 
            this.lblNoticeDec.AutoSize = true;
            this.lblNoticeDec.Font = new System.Drawing.Font("MD개성체", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblNoticeDec.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.lblNoticeDec.Location = new System.Drawing.Point(28, 320);
            this.lblNoticeDec.Name = "lblNoticeDec";
            this.lblNoticeDec.Size = new System.Drawing.Size(333, 22);
            this.lblNoticeDec.TabIndex = 6;
            this.lblNoticeDec.Text = "암호화할 평문을 제출해주세요 :)";
            // 
            // UCEncryption
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblNoticeDec);
            this.Controls.Add(this.btnSubmitNomalTxt);
            this.Controls.Add(this.txtbxInputEnc);
            this.Name = "UCEncryption";
            this.Size = new System.Drawing.Size(675, 382);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox txtbxInputEnc;
        private ns1.BunifuElipse elipseTxtbxInputEnc;
        private System.Windows.Forms.Button btnSubmitNomalTxt;
        private System.Windows.Forms.Label lblNoticeDec;
    }
}
