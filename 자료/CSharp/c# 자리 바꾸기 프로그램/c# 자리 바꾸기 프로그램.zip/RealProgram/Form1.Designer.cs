﻿
namespace RealProgram
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label_teacher = new System.Windows.Forms.Label();
            this.label_num4 = new System.Windows.Forms.Label();
            this.label_num5 = new System.Windows.Forms.Label();
            this.label_num12 = new System.Windows.Forms.Label();
            this.label_num13 = new System.Windows.Forms.Label();
            this.label_num1 = new System.Windows.Forms.Label();
            this.label_num2 = new System.Windows.Forms.Label();
            this.label_num3 = new System.Windows.Forms.Label();
            this.label_num6 = new System.Windows.Forms.Label();
            this.label_num7 = new System.Windows.Forms.Label();
            this.label_num8 = new System.Windows.Forms.Label();
            this.label_num9 = new System.Windows.Forms.Label();
            this.label_num14 = new System.Windows.Forms.Label();
            this.label_num15 = new System.Windows.Forms.Label();
            this.label_num16 = new System.Windows.Forms.Label();
            this.label_num17 = new System.Windows.Forms.Label();
            this.label_num20 = new System.Windows.Forms.Label();
            this.label_num21 = new System.Windows.Forms.Label();
            this.label_num10 = new System.Windows.Forms.Label();
            this.label_num11 = new System.Windows.Forms.Label();
            this.label_num18 = new System.Windows.Forms.Label();
            this.label_num19 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label_num22 = new System.Windows.Forms.Label();
            this.label_num24 = new System.Windows.Forms.Label();
            this.label_num23 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label_teacher
            // 
            this.label_teacher.BackColor = System.Drawing.Color.White;
            this.label_teacher.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label_teacher.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_teacher.Location = new System.Drawing.Point(12, 9);
            this.label_teacher.Name = "label_teacher";
            this.label_teacher.Size = new System.Drawing.Size(673, 54);
            this.label_teacher.TabIndex = 0;
            this.label_teacher.Text = "교사";
            this.label_teacher.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_teacher.Click += new System.EventHandler(this.label_teacher_Click);
            this.label_teacher.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label_teacher_MouseDown);
            this.label_teacher.MouseUp += new System.Windows.Forms.MouseEventHandler(this.label_teacher_MouseUp);
            // 
            // label_num4
            // 
            this.label_num4.BackColor = System.Drawing.Color.White;
            this.label_num4.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num4.Location = new System.Drawing.Point(369, 86);
            this.label_num4.Name = "label_num4";
            this.label_num4.Size = new System.Drawing.Size(83, 54);
            this.label_num4.TabIndex = 0;
            this.label_num4.Text = "4";
            this.label_num4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num5
            // 
            this.label_num5.BackColor = System.Drawing.Color.White;
            this.label_num5.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num5.Location = new System.Drawing.Point(513, 86);
            this.label_num5.Name = "label_num5";
            this.label_num5.Size = new System.Drawing.Size(83, 54);
            this.label_num5.TabIndex = 0;
            this.label_num5.Text = "5";
            this.label_num5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num12
            // 
            this.label_num12.BackColor = System.Drawing.Color.White;
            this.label_num12.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num12.Location = new System.Drawing.Point(602, 160);
            this.label_num12.Name = "label_num12";
            this.label_num12.Size = new System.Drawing.Size(83, 54);
            this.label_num12.TabIndex = 0;
            this.label_num12.Text = "12";
            this.label_num12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num13
            // 
            this.label_num13.BackColor = System.Drawing.Color.White;
            this.label_num13.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num13.Location = new System.Drawing.Point(12, 236);
            this.label_num13.Name = "label_num13";
            this.label_num13.Size = new System.Drawing.Size(83, 54);
            this.label_num13.TabIndex = 0;
            this.label_num13.Text = "13";
            this.label_num13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num1
            // 
            this.label_num1.BackColor = System.Drawing.Color.White;
            this.label_num1.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num1.Location = new System.Drawing.Point(12, 86);
            this.label_num1.Name = "label_num1";
            this.label_num1.Size = new System.Drawing.Size(83, 54);
            this.label_num1.TabIndex = 0;
            this.label_num1.Text = "1";
            this.label_num1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num2
            // 
            this.label_num2.BackColor = System.Drawing.Color.White;
            this.label_num2.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num2.Location = new System.Drawing.Point(108, 86);
            this.label_num2.Name = "label_num2";
            this.label_num2.Size = new System.Drawing.Size(83, 54);
            this.label_num2.TabIndex = 0;
            this.label_num2.Text = "2";
            this.label_num2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num3
            // 
            this.label_num3.BackColor = System.Drawing.Color.White;
            this.label_num3.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num3.Location = new System.Drawing.Point(280, 86);
            this.label_num3.Name = "label_num3";
            this.label_num3.Size = new System.Drawing.Size(83, 54);
            this.label_num3.TabIndex = 0;
            this.label_num3.Text = "3";
            this.label_num3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num6
            // 
            this.label_num6.BackColor = System.Drawing.Color.White;
            this.label_num6.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num6.Location = new System.Drawing.Point(602, 86);
            this.label_num6.Name = "label_num6";
            this.label_num6.Size = new System.Drawing.Size(83, 54);
            this.label_num6.TabIndex = 0;
            this.label_num6.Text = "6";
            this.label_num6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num7
            // 
            this.label_num7.BackColor = System.Drawing.Color.White;
            this.label_num7.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num7.Location = new System.Drawing.Point(12, 160);
            this.label_num7.Name = "label_num7";
            this.label_num7.Size = new System.Drawing.Size(83, 54);
            this.label_num7.TabIndex = 0;
            this.label_num7.Text = "7";
            this.label_num7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num8
            // 
            this.label_num8.BackColor = System.Drawing.Color.White;
            this.label_num8.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num8.Location = new System.Drawing.Point(108, 160);
            this.label_num8.Name = "label_num8";
            this.label_num8.Size = new System.Drawing.Size(83, 54);
            this.label_num8.TabIndex = 0;
            this.label_num8.Text = "8";
            this.label_num8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num9
            // 
            this.label_num9.BackColor = System.Drawing.Color.White;
            this.label_num9.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num9.Location = new System.Drawing.Point(280, 160);
            this.label_num9.Name = "label_num9";
            this.label_num9.Size = new System.Drawing.Size(83, 54);
            this.label_num9.TabIndex = 0;
            this.label_num9.Text = "9";
            this.label_num9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num14
            // 
            this.label_num14.BackColor = System.Drawing.Color.White;
            this.label_num14.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num14.Location = new System.Drawing.Point(108, 236);
            this.label_num14.Name = "label_num14";
            this.label_num14.Size = new System.Drawing.Size(83, 54);
            this.label_num14.TabIndex = 0;
            this.label_num14.Text = "14";
            this.label_num14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num15
            // 
            this.label_num15.BackColor = System.Drawing.Color.White;
            this.label_num15.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num15.Location = new System.Drawing.Point(280, 236);
            this.label_num15.Name = "label_num15";
            this.label_num15.Size = new System.Drawing.Size(83, 54);
            this.label_num15.TabIndex = 0;
            this.label_num15.Text = "15";
            this.label_num15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num16
            // 
            this.label_num16.BackColor = System.Drawing.Color.White;
            this.label_num16.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num16.Location = new System.Drawing.Point(369, 236);
            this.label_num16.Name = "label_num16";
            this.label_num16.Size = new System.Drawing.Size(83, 54);
            this.label_num16.TabIndex = 0;
            this.label_num16.Text = "16";
            this.label_num16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num17
            // 
            this.label_num17.BackColor = System.Drawing.Color.White;
            this.label_num17.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num17.Location = new System.Drawing.Point(513, 236);
            this.label_num17.Name = "label_num17";
            this.label_num17.Size = new System.Drawing.Size(83, 54);
            this.label_num17.TabIndex = 0;
            this.label_num17.Text = "17";
            this.label_num17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num20
            // 
            this.label_num20.BackColor = System.Drawing.Color.White;
            this.label_num20.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num20.Location = new System.Drawing.Point(108, 315);
            this.label_num20.Name = "label_num20";
            this.label_num20.Size = new System.Drawing.Size(83, 54);
            this.label_num20.TabIndex = 0;
            this.label_num20.Text = "20";
            this.label_num20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num21
            // 
            this.label_num21.BackColor = System.Drawing.Color.White;
            this.label_num21.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num21.Location = new System.Drawing.Point(280, 315);
            this.label_num21.Name = "label_num21";
            this.label_num21.Size = new System.Drawing.Size(83, 54);
            this.label_num21.TabIndex = 0;
            this.label_num21.Text = "21";
            this.label_num21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num10
            // 
            this.label_num10.BackColor = System.Drawing.Color.White;
            this.label_num10.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num10.Location = new System.Drawing.Point(369, 160);
            this.label_num10.Name = "label_num10";
            this.label_num10.Size = new System.Drawing.Size(83, 54);
            this.label_num10.TabIndex = 0;
            this.label_num10.Text = "10";
            this.label_num10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num11
            // 
            this.label_num11.BackColor = System.Drawing.Color.White;
            this.label_num11.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num11.Location = new System.Drawing.Point(513, 160);
            this.label_num11.Name = "label_num11";
            this.label_num11.Size = new System.Drawing.Size(83, 54);
            this.label_num11.TabIndex = 0;
            this.label_num11.Text = "11";
            this.label_num11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num18
            // 
            this.label_num18.BackColor = System.Drawing.Color.White;
            this.label_num18.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num18.Location = new System.Drawing.Point(602, 236);
            this.label_num18.Name = "label_num18";
            this.label_num18.Size = new System.Drawing.Size(83, 54);
            this.label_num18.TabIndex = 0;
            this.label_num18.Text = "18";
            this.label_num18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num19
            // 
            this.label_num19.BackColor = System.Drawing.Color.White;
            this.label_num19.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num19.Location = new System.Drawing.Point(12, 315);
            this.label_num19.Name = "label_num19";
            this.label_num19.Size = new System.Drawing.Size(83, 54);
            this.label_num19.TabIndex = 0;
            this.label_num19.Text = "19";
            this.label_num19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Location = new System.Drawing.Point(870, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(54, 54);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(810, 9);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(54, 54);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // label_num22
            // 
            this.label_num22.BackColor = System.Drawing.Color.White;
            this.label_num22.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num22.Location = new System.Drawing.Point(369, 315);
            this.label_num22.Name = "label_num22";
            this.label_num22.Size = new System.Drawing.Size(83, 54);
            this.label_num22.TabIndex = 2;
            this.label_num22.Text = "22";
            this.label_num22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num24
            // 
            this.label_num24.BackColor = System.Drawing.Color.White;
            this.label_num24.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num24.Location = new System.Drawing.Point(602, 315);
            this.label_num24.Name = "label_num24";
            this.label_num24.Size = new System.Drawing.Size(83, 54);
            this.label_num24.TabIndex = 4;
            this.label_num24.Text = "24";
            this.label_num24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_num23
            // 
            this.label_num23.BackColor = System.Drawing.Color.White;
            this.label_num23.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_num23.Location = new System.Drawing.Point(513, 315);
            this.label_num23.Name = "label_num23";
            this.label_num23.Size = new System.Drawing.Size(83, 54);
            this.label_num23.TabIndex = 3;
            this.label_num23.Text = "23";
            this.label_num23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.YellowGreen;
            this.ClientSize = new System.Drawing.Size(936, 463);
            this.Controls.Add(this.label_num24);
            this.Controls.Add(this.label_num23);
            this.Controls.Add(this.label_num22);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label_num19);
            this.Controls.Add(this.label_num13);
            this.Controls.Add(this.label_num18);
            this.Controls.Add(this.label_num12);
            this.Controls.Add(this.label_num17);
            this.Controls.Add(this.label_num16);
            this.Controls.Add(this.label_num9);
            this.Controls.Add(this.label_num21);
            this.Controls.Add(this.label_num8);
            this.Controls.Add(this.label_num15);
            this.Controls.Add(this.label_num3);
            this.Controls.Add(this.label_num20);
            this.Controls.Add(this.label_num7);
            this.Controls.Add(this.label_num14);
            this.Controls.Add(this.label_num2);
            this.Controls.Add(this.label_num6);
            this.Controls.Add(this.label_num1);
            this.Controls.Add(this.label_num11);
            this.Controls.Add(this.label_num10);
            this.Controls.Add(this.label_num5);
            this.Controls.Add(this.label_num4);
            this.Controls.Add(this.label_teacher);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.DoubleClick += new System.EventHandler(this.Form1_DoubleClick);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label_teacher;
        private System.Windows.Forms.Label label_num4;
        private System.Windows.Forms.Label label_num5;
        private System.Windows.Forms.Label label_num12;
        private System.Windows.Forms.Label label_num13;
        private System.Windows.Forms.Label label_num1;
        private System.Windows.Forms.Label label_num2;
        private System.Windows.Forms.Label label_num3;
        private System.Windows.Forms.Label label_num6;
        private System.Windows.Forms.Label label_num7;
        private System.Windows.Forms.Label label_num8;
        private System.Windows.Forms.Label label_num9;
        private System.Windows.Forms.Label label_num14;
        private System.Windows.Forms.Label label_num15;
        private System.Windows.Forms.Label label_num16;
        private System.Windows.Forms.Label label_num17;
        private System.Windows.Forms.Label label_num20;
        private System.Windows.Forms.Label label_num21;
        private System.Windows.Forms.Label label_num10;
        private System.Windows.Forms.Label label_num11;
        private System.Windows.Forms.Label label_num18;
        private System.Windows.Forms.Label label_num19;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label_num22;
        private System.Windows.Forms.Label label_num24;
        private System.Windows.Forms.Label label_num23;
    }
}

