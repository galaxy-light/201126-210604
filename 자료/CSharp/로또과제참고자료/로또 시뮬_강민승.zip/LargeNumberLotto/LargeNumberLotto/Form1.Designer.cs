﻿
namespace LargeNumberLotto
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.draw_one = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.bonus = new System.Windows.Forms.Label();
            this.title = new System.Windows.Forms.Label();
            this.draw_52 = new System.Windows.Forms.Button();
            this.draw_520 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.year_label = new System.Windows.Forms.Label();
            this.week_label = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.mypick_btn = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.mypick_2 = new System.Windows.Forms.Label();
            this.mypick_3 = new System.Windows.Forms.Label();
            this.mypick_4 = new System.Windows.Forms.Label();
            this.mypick_5 = new System.Windows.Forms.Label();
            this.mypick_6 = new System.Windows.Forms.Label();
            this.mypick_1 = new System.Windows.Forms.Label();
            this.autopick_1 = new System.Windows.Forms.Label();
            this.autopick_2 = new System.Windows.Forms.Label();
            this.autopick_3 = new System.Windows.Forms.Label();
            this.autopick_5 = new System.Windows.Forms.Label();
            this.autopick_4 = new System.Windows.Forms.Label();
            this.autopick_6 = new System.Windows.Forms.Label();
            this.pick_6 = new System.Windows.Forms.Label();
            this.pick_4 = new System.Windows.Forms.Label();
            this.pick_5 = new System.Windows.Forms.Label();
            this.pick_3 = new System.Windows.Forms.Label();
            this.pick_2 = new System.Windows.Forms.Label();
            this.pick_1 = new System.Windows.Forms.Label();
            this.pickodd_6 = new System.Windows.Forms.Label();
            this.pickodd_4 = new System.Windows.Forms.Label();
            this.pickodd_5 = new System.Windows.Forms.Label();
            this.pickodd_3 = new System.Windows.Forms.Label();
            this.pickodd_2 = new System.Windows.Forms.Label();
            this.pickodd_1 = new System.Windows.Forms.Label();
            this.pick40s_6 = new System.Windows.Forms.Label();
            this.pick40s_4 = new System.Windows.Forms.Label();
            this.pick40s_5 = new System.Windows.Forms.Label();
            this.pick40s_3 = new System.Windows.Forms.Label();
            this.pick40s_2 = new System.Windows.Forms.Label();
            this.pick40s_1 = new System.Windows.Forms.Label();
            this.mypick_earn_money = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.mypick_total_money = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.autopick_earn_money = new System.Windows.Forms.Label();
            this.autopick_total_money = new System.Windows.Forms.Label();
            this.pick_total_money = new System.Windows.Forms.Label();
            this.pick_earn_money = new System.Windows.Forms.Label();
            this.pickodd_total_money = new System.Windows.Forms.Label();
            this.pickodd_earn_money = new System.Windows.Forms.Label();
            this.pick40s_total_money = new System.Windows.Forms.Label();
            this.pick40s_earn_money = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.mypick_5th = new System.Windows.Forms.Label();
            this.mypick_4th = new System.Windows.Forms.Label();
            this.mypick_3rd = new System.Windows.Forms.Label();
            this.mypick_2nd = new System.Windows.Forms.Label();
            this.mypick_1st = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.autopick_1st = new System.Windows.Forms.Label();
            this.autopick_2nd = new System.Windows.Forms.Label();
            this.autopick_3rd = new System.Windows.Forms.Label();
            this.autopick_4th = new System.Windows.Forms.Label();
            this.autopick_5th = new System.Windows.Forms.Label();
            this.pick_1st = new System.Windows.Forms.Label();
            this.pick_2nd = new System.Windows.Forms.Label();
            this.pick_3rd = new System.Windows.Forms.Label();
            this.pick_4th = new System.Windows.Forms.Label();
            this.pick_5th = new System.Windows.Forms.Label();
            this.pickodd_1st = new System.Windows.Forms.Label();
            this.pickodd_2nd = new System.Windows.Forms.Label();
            this.pickodd_3rd = new System.Windows.Forms.Label();
            this.pickodd_4th = new System.Windows.Forms.Label();
            this.pickodd_5th = new System.Windows.Forms.Label();
            this.pick40s_1st = new System.Windows.Forms.Label();
            this.pick40s_2nd = new System.Windows.Forms.Label();
            this.pick40s_3rd = new System.Windows.Forms.Label();
            this.pick40s_4th = new System.Windows.Forms.Label();
            this.pick40s_5th = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.buy_label = new System.Windows.Forms.Label();
            this.draw_auto = new System.Windows.Forms.Button();
            this.draw_stop = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.spent_money = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // draw_one
            // 
            this.draw_one.Location = new System.Drawing.Point(59, 82);
            this.draw_one.Name = "draw_one";
            this.draw_one.Size = new System.Drawing.Size(126, 30);
            this.draw_one.TabIndex = 0;
            this.draw_one.Text = "1회 추첨";
            this.draw_one.UseVisualStyleBackColor = true;
            this.draw_one.Click += new System.EventHandler(this.draw_one_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 12F);
            this.label1.Location = new System.Drawing.Point(56, 174);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 12F);
            this.label2.Location = new System.Drawing.Point(109, 174);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 12F);
            this.label3.Location = new System.Drawing.Point(164, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("굴림", 12F);
            this.label4.Location = new System.Drawing.Point(219, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("굴림", 12F);
            this.label5.Location = new System.Drawing.Point(274, 174);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "label5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("굴림", 12F);
            this.label6.Location = new System.Drawing.Point(326, 174);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 16);
            this.label6.TabIndex = 6;
            this.label6.Text = "label6";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("굴림", 12F);
            this.label7.Location = new System.Drawing.Point(435, 174);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 16);
            this.label7.TabIndex = 7;
            this.label7.Text = "label7";
            // 
            // bonus
            // 
            this.bonus.AutoSize = true;
            this.bonus.Font = new System.Drawing.Font("굴림", 12F);
            this.bonus.Location = new System.Drawing.Point(381, 174);
            this.bonus.Name = "bonus";
            this.bonus.Size = new System.Drawing.Size(54, 16);
            this.bonus.TabIndex = 14;
            this.bonus.Text = "bonus";
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("굴림", 20F);
            this.title.Location = new System.Drawing.Point(433, 20);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(210, 27);
            this.title.TabIndex = 22;
            this.title.Text = "로또 시뮬레이션";
            // 
            // draw_52
            // 
            this.draw_52.Location = new System.Drawing.Point(197, 82);
            this.draw_52.Name = "draw_52";
            this.draw_52.Size = new System.Drawing.Size(126, 30);
            this.draw_52.TabIndex = 23;
            this.draw_52.Text = "1년 추첨(52회)";
            this.draw_52.UseVisualStyleBackColor = true;
            this.draw_52.Click += new System.EventHandler(this.draw_52_Click);
            // 
            // draw_520
            // 
            this.draw_520.Location = new System.Drawing.Point(329, 82);
            this.draw_520.Name = "draw_520";
            this.draw_520.Size = new System.Drawing.Size(126, 30);
            this.draw_520.TabIndex = 24;
            this.draw_520.Text = "10년추첨(520회)";
            this.draw_520.UseVisualStyleBackColor = true;
            this.draw_520.Click += new System.EventHandler(this.draw_520_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("굴림", 12F);
            this.label8.Location = new System.Drawing.Point(605, 87);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(24, 16);
            this.label8.TabIndex = 25;
            this.label8.Text = "년";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("굴림", 12F);
            this.label9.Location = new System.Drawing.Point(605, 114);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(24, 16);
            this.label9.TabIndex = 26;
            this.label9.Text = "주";
            // 
            // year_label
            // 
            this.year_label.AutoSize = true;
            this.year_label.Font = new System.Drawing.Font("굴림", 12F);
            this.year_label.Location = new System.Drawing.Point(525, 87);
            this.year_label.Name = "year_label";
            this.year_label.Size = new System.Drawing.Size(16, 16);
            this.year_label.TabIndex = 27;
            this.year_label.Text = "0";
            // 
            // week_label
            // 
            this.week_label.AutoSize = true;
            this.week_label.Font = new System.Drawing.Font("굴림", 12F);
            this.week_label.Location = new System.Drawing.Point(525, 114);
            this.week_label.Name = "week_label";
            this.week_label.Size = new System.Drawing.Size(16, 16);
            this.week_label.TabIndex = 28;
            this.week_label.Text = "0";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(199, 212);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(71, 21);
            this.textBox1.TabIndex = 29;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(287, 212);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(71, 21);
            this.textBox2.TabIndex = 30;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(370, 212);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(71, 21);
            this.textBox3.TabIndex = 31;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(199, 239);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(71, 21);
            this.textBox4.TabIndex = 32;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(287, 239);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(71, 21);
            this.textBox5.TabIndex = 33;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(370, 239);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(71, 21);
            this.textBox6.TabIndex = 34;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("굴림", 12F);
            this.label10.Location = new System.Drawing.Point(44, 413);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(102, 16);
            this.label10.TabIndex = 35;
            this.label10.Text = "2. 자동(매회)";
            // 
            // mypick_btn
            // 
            this.mypick_btn.Location = new System.Drawing.Point(59, 212);
            this.mypick_btn.Name = "mypick_btn";
            this.mypick_btn.Size = new System.Drawing.Size(126, 48);
            this.mypick_btn.TabIndex = 36;
            this.mypick_btn.Text = "나의 픽(공백은랜덤)";
            this.mypick_btn.UseVisualStyleBackColor = true;
            this.mypick_btn.Click += new System.EventHandler(this.mypick_btn_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("굴림", 12F);
            this.label11.Location = new System.Drawing.Point(44, 372);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(79, 16);
            this.label11.TabIndex = 37;
            this.label11.Text = "1. 나의 픽";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("굴림", 12F);
            this.label12.Location = new System.Drawing.Point(44, 452);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 16);
            this.label12.TabIndex = 38;
            this.label12.Text = "3. 1 2 3 4 5 6";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("굴림", 12F);
            this.label13.Location = new System.Drawing.Point(44, 528);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(75, 16);
            this.label13.TabIndex = 39;
            this.label13.Text = "5. 40번대";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("굴림", 12F);
            this.label14.Location = new System.Drawing.Point(44, 491);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(96, 16);
            this.label14.TabIndex = 40;
            this.label14.Text = "4. 2 4 6 8 10";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("굴림", 12F);
            this.label15.Location = new System.Drawing.Point(131, 372);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(0, 16);
            this.label15.TabIndex = 41;
            // 
            // mypick_2
            // 
            this.mypick_2.AutoSize = true;
            this.mypick_2.Font = new System.Drawing.Font("굴림", 12F);
            this.mypick_2.Location = new System.Drawing.Point(206, 372);
            this.mypick_2.Name = "mypick_2";
            this.mypick_2.Size = new System.Drawing.Size(16, 16);
            this.mypick_2.TabIndex = 42;
            this.mypick_2.Text = "-";
            // 
            // mypick_3
            // 
            this.mypick_3.AutoSize = true;
            this.mypick_3.Font = new System.Drawing.Font("굴림", 12F);
            this.mypick_3.Location = new System.Drawing.Point(255, 372);
            this.mypick_3.Name = "mypick_3";
            this.mypick_3.Size = new System.Drawing.Size(16, 16);
            this.mypick_3.TabIndex = 43;
            this.mypick_3.Text = "-";
            // 
            // mypick_4
            // 
            this.mypick_4.AutoSize = true;
            this.mypick_4.Font = new System.Drawing.Font("굴림", 12F);
            this.mypick_4.Location = new System.Drawing.Point(305, 372);
            this.mypick_4.Name = "mypick_4";
            this.mypick_4.Size = new System.Drawing.Size(16, 16);
            this.mypick_4.TabIndex = 44;
            this.mypick_4.Text = "-";
            // 
            // mypick_5
            // 
            this.mypick_5.AutoSize = true;
            this.mypick_5.Font = new System.Drawing.Font("굴림", 12F);
            this.mypick_5.Location = new System.Drawing.Point(355, 372);
            this.mypick_5.Name = "mypick_5";
            this.mypick_5.Size = new System.Drawing.Size(16, 16);
            this.mypick_5.TabIndex = 45;
            this.mypick_5.Text = "-";
            // 
            // mypick_6
            // 
            this.mypick_6.AutoSize = true;
            this.mypick_6.Font = new System.Drawing.Font("굴림", 12F);
            this.mypick_6.Location = new System.Drawing.Point(405, 372);
            this.mypick_6.Name = "mypick_6";
            this.mypick_6.Size = new System.Drawing.Size(16, 16);
            this.mypick_6.TabIndex = 46;
            this.mypick_6.Text = "-";
            // 
            // mypick_1
            // 
            this.mypick_1.AutoSize = true;
            this.mypick_1.Font = new System.Drawing.Font("굴림", 12F);
            this.mypick_1.Location = new System.Drawing.Point(156, 372);
            this.mypick_1.Name = "mypick_1";
            this.mypick_1.Size = new System.Drawing.Size(16, 16);
            this.mypick_1.TabIndex = 47;
            this.mypick_1.Text = "-";
            // 
            // autopick_1
            // 
            this.autopick_1.AutoSize = true;
            this.autopick_1.Font = new System.Drawing.Font("굴림", 12F);
            this.autopick_1.Location = new System.Drawing.Point(156, 413);
            this.autopick_1.Name = "autopick_1";
            this.autopick_1.Size = new System.Drawing.Size(16, 16);
            this.autopick_1.TabIndex = 48;
            this.autopick_1.Text = "-";
            // 
            // autopick_2
            // 
            this.autopick_2.AutoSize = true;
            this.autopick_2.Font = new System.Drawing.Font("굴림", 12F);
            this.autopick_2.Location = new System.Drawing.Point(205, 413);
            this.autopick_2.Name = "autopick_2";
            this.autopick_2.Size = new System.Drawing.Size(16, 16);
            this.autopick_2.TabIndex = 49;
            this.autopick_2.Text = "-";
            // 
            // autopick_3
            // 
            this.autopick_3.AutoSize = true;
            this.autopick_3.Font = new System.Drawing.Font("굴림", 12F);
            this.autopick_3.Location = new System.Drawing.Point(255, 413);
            this.autopick_3.Name = "autopick_3";
            this.autopick_3.Size = new System.Drawing.Size(16, 16);
            this.autopick_3.TabIndex = 50;
            this.autopick_3.Text = "-";
            // 
            // autopick_5
            // 
            this.autopick_5.AutoSize = true;
            this.autopick_5.Font = new System.Drawing.Font("굴림", 12F);
            this.autopick_5.Location = new System.Drawing.Point(355, 413);
            this.autopick_5.Name = "autopick_5";
            this.autopick_5.Size = new System.Drawing.Size(16, 16);
            this.autopick_5.TabIndex = 51;
            this.autopick_5.Text = "-";
            // 
            // autopick_4
            // 
            this.autopick_4.AutoSize = true;
            this.autopick_4.Font = new System.Drawing.Font("굴림", 12F);
            this.autopick_4.Location = new System.Drawing.Point(305, 413);
            this.autopick_4.Name = "autopick_4";
            this.autopick_4.Size = new System.Drawing.Size(16, 16);
            this.autopick_4.TabIndex = 52;
            this.autopick_4.Text = "-";
            // 
            // autopick_6
            // 
            this.autopick_6.AutoSize = true;
            this.autopick_6.Font = new System.Drawing.Font("굴림", 12F);
            this.autopick_6.Location = new System.Drawing.Point(405, 413);
            this.autopick_6.Name = "autopick_6";
            this.autopick_6.Size = new System.Drawing.Size(16, 16);
            this.autopick_6.TabIndex = 53;
            this.autopick_6.Text = "-";
            // 
            // pick_6
            // 
            this.pick_6.AutoSize = true;
            this.pick_6.Font = new System.Drawing.Font("굴림", 12F);
            this.pick_6.Location = new System.Drawing.Point(405, 452);
            this.pick_6.Name = "pick_6";
            this.pick_6.Size = new System.Drawing.Size(16, 16);
            this.pick_6.TabIndex = 59;
            this.pick_6.Text = "6";
            // 
            // pick_4
            // 
            this.pick_4.AutoSize = true;
            this.pick_4.Font = new System.Drawing.Font("굴림", 12F);
            this.pick_4.Location = new System.Drawing.Point(311, 452);
            this.pick_4.Name = "pick_4";
            this.pick_4.Size = new System.Drawing.Size(17, 16);
            this.pick_4.TabIndex = 58;
            this.pick_4.Text = "4";
            // 
            // pick_5
            // 
            this.pick_5.AutoSize = true;
            this.pick_5.Font = new System.Drawing.Font("굴림", 12F);
            this.pick_5.Location = new System.Drawing.Point(361, 452);
            this.pick_5.Name = "pick_5";
            this.pick_5.Size = new System.Drawing.Size(16, 16);
            this.pick_5.TabIndex = 57;
            this.pick_5.Text = "5";
            // 
            // pick_3
            // 
            this.pick_3.AutoSize = true;
            this.pick_3.Font = new System.Drawing.Font("굴림", 12F);
            this.pick_3.Location = new System.Drawing.Point(261, 452);
            this.pick_3.Name = "pick_3";
            this.pick_3.Size = new System.Drawing.Size(16, 16);
            this.pick_3.TabIndex = 56;
            this.pick_3.Text = "3";
            // 
            // pick_2
            // 
            this.pick_2.AutoSize = true;
            this.pick_2.Font = new System.Drawing.Font("굴림", 12F);
            this.pick_2.Location = new System.Drawing.Point(211, 452);
            this.pick_2.Name = "pick_2";
            this.pick_2.Size = new System.Drawing.Size(16, 16);
            this.pick_2.TabIndex = 55;
            this.pick_2.Text = "2";
            // 
            // pick_1
            // 
            this.pick_1.AutoSize = true;
            this.pick_1.Font = new System.Drawing.Font("굴림", 12F);
            this.pick_1.Location = new System.Drawing.Point(162, 452);
            this.pick_1.Name = "pick_1";
            this.pick_1.Size = new System.Drawing.Size(16, 16);
            this.pick_1.TabIndex = 54;
            this.pick_1.Text = "1";
            // 
            // pickodd_6
            // 
            this.pickodd_6.AutoSize = true;
            this.pickodd_6.Font = new System.Drawing.Font("굴림", 12F);
            this.pickodd_6.Location = new System.Drawing.Point(402, 491);
            this.pickodd_6.Name = "pickodd_6";
            this.pickodd_6.Size = new System.Drawing.Size(24, 16);
            this.pickodd_6.TabIndex = 65;
            this.pickodd_6.Text = "12";
            // 
            // pickodd_4
            // 
            this.pickodd_4.AutoSize = true;
            this.pickodd_4.Font = new System.Drawing.Font("굴림", 12F);
            this.pickodd_4.Location = new System.Drawing.Point(308, 491);
            this.pickodd_4.Name = "pickodd_4";
            this.pickodd_4.Size = new System.Drawing.Size(16, 16);
            this.pickodd_4.TabIndex = 64;
            this.pickodd_4.Text = "8";
            // 
            // pickodd_5
            // 
            this.pickodd_5.AutoSize = true;
            this.pickodd_5.Font = new System.Drawing.Font("굴림", 12F);
            this.pickodd_5.Location = new System.Drawing.Point(355, 491);
            this.pickodd_5.Name = "pickodd_5";
            this.pickodd_5.Size = new System.Drawing.Size(24, 16);
            this.pickodd_5.TabIndex = 63;
            this.pickodd_5.Text = "10";
            // 
            // pickodd_3
            // 
            this.pickodd_3.AutoSize = true;
            this.pickodd_3.Font = new System.Drawing.Font("굴림", 12F);
            this.pickodd_3.Location = new System.Drawing.Point(258, 491);
            this.pickodd_3.Name = "pickodd_3";
            this.pickodd_3.Size = new System.Drawing.Size(16, 16);
            this.pickodd_3.TabIndex = 62;
            this.pickodd_3.Text = "6";
            // 
            // pickodd_2
            // 
            this.pickodd_2.AutoSize = true;
            this.pickodd_2.Font = new System.Drawing.Font("굴림", 12F);
            this.pickodd_2.Location = new System.Drawing.Point(209, 491);
            this.pickodd_2.Name = "pickodd_2";
            this.pickodd_2.Size = new System.Drawing.Size(17, 16);
            this.pickodd_2.TabIndex = 61;
            this.pickodd_2.Text = "4";
            // 
            // pickodd_1
            // 
            this.pickodd_1.AutoSize = true;
            this.pickodd_1.Font = new System.Drawing.Font("굴림", 12F);
            this.pickodd_1.Location = new System.Drawing.Point(158, 491);
            this.pickodd_1.Name = "pickodd_1";
            this.pickodd_1.Size = new System.Drawing.Size(16, 16);
            this.pickodd_1.TabIndex = 60;
            this.pickodd_1.Text = "2";
            // 
            // pick40s_6
            // 
            this.pick40s_6.AutoSize = true;
            this.pick40s_6.Font = new System.Drawing.Font("굴림", 12F);
            this.pick40s_6.Location = new System.Drawing.Point(402, 528);
            this.pick40s_6.Name = "pick40s_6";
            this.pick40s_6.Size = new System.Drawing.Size(25, 16);
            this.pick40s_6.TabIndex = 71;
            this.pick40s_6.Text = "45";
            // 
            // pick40s_4
            // 
            this.pick40s_4.AutoSize = true;
            this.pick40s_4.Font = new System.Drawing.Font("굴림", 12F);
            this.pick40s_4.Location = new System.Drawing.Point(305, 528);
            this.pick40s_4.Name = "pick40s_4";
            this.pick40s_4.Size = new System.Drawing.Size(25, 16);
            this.pick40s_4.TabIndex = 70;
            this.pick40s_4.Text = "43";
            // 
            // pick40s_5
            // 
            this.pick40s_5.AutoSize = true;
            this.pick40s_5.Font = new System.Drawing.Font("굴림", 12F);
            this.pick40s_5.Location = new System.Drawing.Point(355, 528);
            this.pick40s_5.Name = "pick40s_5";
            this.pick40s_5.Size = new System.Drawing.Size(26, 16);
            this.pick40s_5.TabIndex = 69;
            this.pick40s_5.Text = "44";
            // 
            // pick40s_3
            // 
            this.pick40s_3.AutoSize = true;
            this.pick40s_3.Font = new System.Drawing.Font("굴림", 12F);
            this.pick40s_3.Location = new System.Drawing.Point(255, 528);
            this.pick40s_3.Name = "pick40s_3";
            this.pick40s_3.Size = new System.Drawing.Size(25, 16);
            this.pick40s_3.TabIndex = 68;
            this.pick40s_3.Text = "42";
            // 
            // pick40s_2
            // 
            this.pick40s_2.AutoSize = true;
            this.pick40s_2.Font = new System.Drawing.Font("굴림", 12F);
            this.pick40s_2.Location = new System.Drawing.Point(206, 528);
            this.pick40s_2.Name = "pick40s_2";
            this.pick40s_2.Size = new System.Drawing.Size(25, 16);
            this.pick40s_2.TabIndex = 67;
            this.pick40s_2.Text = "41";
            // 
            // pick40s_1
            // 
            this.pick40s_1.AutoSize = true;
            this.pick40s_1.Font = new System.Drawing.Font("굴림", 12F);
            this.pick40s_1.Location = new System.Drawing.Point(156, 528);
            this.pick40s_1.Name = "pick40s_1";
            this.pick40s_1.Size = new System.Drawing.Size(25, 16);
            this.pick40s_1.TabIndex = 66;
            this.pick40s_1.Text = "40";
            // 
            // mypick_earn_money
            // 
            this.mypick_earn_money.AutoSize = true;
            this.mypick_earn_money.Font = new System.Drawing.Font("굴림", 12F);
            this.mypick_earn_money.Location = new System.Drawing.Point(703, 372);
            this.mypick_earn_money.Name = "mypick_earn_money";
            this.mypick_earn_money.Size = new System.Drawing.Size(16, 16);
            this.mypick_earn_money.TabIndex = 73;
            this.mypick_earn_money.Text = "0";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("굴림", 12F);
            this.label17.Location = new System.Drawing.Point(455, 338);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(56, 16);
            this.label17.TabIndex = 75;
            this.label17.Text = "당첨금";
            // 
            // mypick_total_money
            // 
            this.mypick_total_money.AutoSize = true;
            this.mypick_total_money.Font = new System.Drawing.Font("굴림", 12F);
            this.mypick_total_money.Location = new System.Drawing.Point(455, 372);
            this.mypick_total_money.Name = "mypick_total_money";
            this.mypick_total_money.Size = new System.Drawing.Size(16, 16);
            this.mypick_total_money.TabIndex = 77;
            this.mypick_total_money.Text = "0";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("굴림", 12F);
            this.label20.Location = new System.Drawing.Point(703, 338);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(72, 16);
            this.label20.TabIndex = 81;
            this.label20.Text = "누적손익";
            // 
            // autopick_earn_money
            // 
            this.autopick_earn_money.AutoSize = true;
            this.autopick_earn_money.Font = new System.Drawing.Font("굴림", 12F);
            this.autopick_earn_money.Location = new System.Drawing.Point(703, 413);
            this.autopick_earn_money.Name = "autopick_earn_money";
            this.autopick_earn_money.Size = new System.Drawing.Size(16, 16);
            this.autopick_earn_money.TabIndex = 84;
            this.autopick_earn_money.Text = "0";
            // 
            // autopick_total_money
            // 
            this.autopick_total_money.AutoSize = true;
            this.autopick_total_money.Font = new System.Drawing.Font("굴림", 12F);
            this.autopick_total_money.Location = new System.Drawing.Point(455, 413);
            this.autopick_total_money.Name = "autopick_total_money";
            this.autopick_total_money.Size = new System.Drawing.Size(16, 16);
            this.autopick_total_money.TabIndex = 85;
            this.autopick_total_money.Text = "0";
            // 
            // pick_total_money
            // 
            this.pick_total_money.AutoSize = true;
            this.pick_total_money.Font = new System.Drawing.Font("굴림", 12F);
            this.pick_total_money.Location = new System.Drawing.Point(455, 452);
            this.pick_total_money.Name = "pick_total_money";
            this.pick_total_money.Size = new System.Drawing.Size(16, 16);
            this.pick_total_money.TabIndex = 91;
            this.pick_total_money.Text = "0";
            // 
            // pick_earn_money
            // 
            this.pick_earn_money.AutoSize = true;
            this.pick_earn_money.Font = new System.Drawing.Font("굴림", 12F);
            this.pick_earn_money.Location = new System.Drawing.Point(703, 452);
            this.pick_earn_money.Name = "pick_earn_money";
            this.pick_earn_money.Size = new System.Drawing.Size(16, 16);
            this.pick_earn_money.TabIndex = 90;
            this.pick_earn_money.Text = "0";
            // 
            // pickodd_total_money
            // 
            this.pickodd_total_money.AutoSize = true;
            this.pickodd_total_money.Font = new System.Drawing.Font("굴림", 12F);
            this.pickodd_total_money.Location = new System.Drawing.Point(455, 491);
            this.pickodd_total_money.Name = "pickodd_total_money";
            this.pickodd_total_money.Size = new System.Drawing.Size(16, 16);
            this.pickodd_total_money.TabIndex = 97;
            this.pickodd_total_money.Text = "0";
            // 
            // pickodd_earn_money
            // 
            this.pickodd_earn_money.AutoSize = true;
            this.pickodd_earn_money.Font = new System.Drawing.Font("굴림", 12F);
            this.pickodd_earn_money.Location = new System.Drawing.Point(703, 491);
            this.pickodd_earn_money.Name = "pickodd_earn_money";
            this.pickodd_earn_money.Size = new System.Drawing.Size(16, 16);
            this.pickodd_earn_money.TabIndex = 96;
            this.pickodd_earn_money.Text = "0";
            // 
            // pick40s_total_money
            // 
            this.pick40s_total_money.AutoSize = true;
            this.pick40s_total_money.Font = new System.Drawing.Font("굴림", 12F);
            this.pick40s_total_money.Location = new System.Drawing.Point(455, 528);
            this.pick40s_total_money.Name = "pick40s_total_money";
            this.pick40s_total_money.Size = new System.Drawing.Size(16, 16);
            this.pick40s_total_money.TabIndex = 103;
            this.pick40s_total_money.Text = "0";
            // 
            // pick40s_earn_money
            // 
            this.pick40s_earn_money.AutoSize = true;
            this.pick40s_earn_money.Font = new System.Drawing.Font("굴림", 12F);
            this.pick40s_earn_money.Location = new System.Drawing.Point(703, 528);
            this.pick40s_earn_money.Name = "pick40s_earn_money";
            this.pick40s_earn_money.Size = new System.Drawing.Size(16, 16);
            this.pick40s_earn_money.TabIndex = 102;
            this.pick40s_earn_money.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("굴림", 12F);
            this.label21.Location = new System.Drawing.Point(73, 285);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(366, 16);
            this.label21.TabIndex = 106;
            this.label21.Text = " 1등 50억 2등1억 3등 200만원 4등 5만원 5등 5천원";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("굴림", 12F);
            this.label16.Location = new System.Drawing.Point(886, 301);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(114, 16);
            this.label16.TabIndex = 74;
            this.label16.Text = "역대 등수 누적";
            // 
            // mypick_5th
            // 
            this.mypick_5th.AutoSize = true;
            this.mypick_5th.Font = new System.Drawing.Font("굴림", 12F);
            this.mypick_5th.Location = new System.Drawing.Point(817, 373);
            this.mypick_5th.Name = "mypick_5th";
            this.mypick_5th.Size = new System.Drawing.Size(16, 16);
            this.mypick_5th.TabIndex = 72;
            this.mypick_5th.Text = "0";
            // 
            // mypick_4th
            // 
            this.mypick_4th.AutoSize = true;
            this.mypick_4th.Font = new System.Drawing.Font("굴림", 12F);
            this.mypick_4th.Location = new System.Drawing.Point(868, 373);
            this.mypick_4th.Name = "mypick_4th";
            this.mypick_4th.Size = new System.Drawing.Size(16, 16);
            this.mypick_4th.TabIndex = 107;
            this.mypick_4th.Text = "0";
            // 
            // mypick_3rd
            // 
            this.mypick_3rd.AutoSize = true;
            this.mypick_3rd.Font = new System.Drawing.Font("굴림", 12F);
            this.mypick_3rd.Location = new System.Drawing.Point(919, 373);
            this.mypick_3rd.Name = "mypick_3rd";
            this.mypick_3rd.Size = new System.Drawing.Size(16, 16);
            this.mypick_3rd.TabIndex = 108;
            this.mypick_3rd.Text = "0";
            // 
            // mypick_2nd
            // 
            this.mypick_2nd.AutoSize = true;
            this.mypick_2nd.Font = new System.Drawing.Font("굴림", 12F);
            this.mypick_2nd.Location = new System.Drawing.Point(970, 373);
            this.mypick_2nd.Name = "mypick_2nd";
            this.mypick_2nd.Size = new System.Drawing.Size(16, 16);
            this.mypick_2nd.TabIndex = 109;
            this.mypick_2nd.Text = "0";
            // 
            // mypick_1st
            // 
            this.mypick_1st.AutoSize = true;
            this.mypick_1st.Font = new System.Drawing.Font("굴림", 12F);
            this.mypick_1st.Location = new System.Drawing.Point(1021, 373);
            this.mypick_1st.Name = "mypick_1st";
            this.mypick_1st.Size = new System.Drawing.Size(16, 16);
            this.mypick_1st.TabIndex = 110;
            this.mypick_1st.Text = "0";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("굴림", 12F);
            this.label18.Location = new System.Drawing.Point(817, 338);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(32, 16);
            this.label18.TabIndex = 111;
            this.label18.Text = "5등";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("굴림", 12F);
            this.label19.Location = new System.Drawing.Point(868, 338);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(33, 16);
            this.label19.TabIndex = 112;
            this.label19.Text = "4등";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("굴림", 12F);
            this.label22.Location = new System.Drawing.Point(919, 338);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(32, 16);
            this.label22.TabIndex = 113;
            this.label22.Text = "3등";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("굴림", 12F);
            this.label23.Location = new System.Drawing.Point(970, 338);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(32, 16);
            this.label23.TabIndex = 114;
            this.label23.Text = "2등";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("굴림", 12F);
            this.label24.Location = new System.Drawing.Point(1021, 338);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(32, 16);
            this.label24.TabIndex = 115;
            this.label24.Text = "1등";
            // 
            // autopick_1st
            // 
            this.autopick_1st.AutoSize = true;
            this.autopick_1st.Font = new System.Drawing.Font("굴림", 12F);
            this.autopick_1st.Location = new System.Drawing.Point(1021, 414);
            this.autopick_1st.Name = "autopick_1st";
            this.autopick_1st.Size = new System.Drawing.Size(16, 16);
            this.autopick_1st.TabIndex = 122;
            this.autopick_1st.Text = "0";
            // 
            // autopick_2nd
            // 
            this.autopick_2nd.AutoSize = true;
            this.autopick_2nd.Font = new System.Drawing.Font("굴림", 12F);
            this.autopick_2nd.Location = new System.Drawing.Point(970, 414);
            this.autopick_2nd.Name = "autopick_2nd";
            this.autopick_2nd.Size = new System.Drawing.Size(16, 16);
            this.autopick_2nd.TabIndex = 121;
            this.autopick_2nd.Text = "0";
            // 
            // autopick_3rd
            // 
            this.autopick_3rd.AutoSize = true;
            this.autopick_3rd.Font = new System.Drawing.Font("굴림", 12F);
            this.autopick_3rd.Location = new System.Drawing.Point(919, 414);
            this.autopick_3rd.Name = "autopick_3rd";
            this.autopick_3rd.Size = new System.Drawing.Size(16, 16);
            this.autopick_3rd.TabIndex = 120;
            this.autopick_3rd.Text = "0";
            // 
            // autopick_4th
            // 
            this.autopick_4th.AutoSize = true;
            this.autopick_4th.Font = new System.Drawing.Font("굴림", 12F);
            this.autopick_4th.Location = new System.Drawing.Point(868, 414);
            this.autopick_4th.Name = "autopick_4th";
            this.autopick_4th.Size = new System.Drawing.Size(16, 16);
            this.autopick_4th.TabIndex = 119;
            this.autopick_4th.Text = "0";
            // 
            // autopick_5th
            // 
            this.autopick_5th.AutoSize = true;
            this.autopick_5th.Font = new System.Drawing.Font("굴림", 12F);
            this.autopick_5th.Location = new System.Drawing.Point(817, 414);
            this.autopick_5th.Name = "autopick_5th";
            this.autopick_5th.Size = new System.Drawing.Size(16, 16);
            this.autopick_5th.TabIndex = 118;
            this.autopick_5th.Text = "0";
            // 
            // pick_1st
            // 
            this.pick_1st.AutoSize = true;
            this.pick_1st.Font = new System.Drawing.Font("굴림", 12F);
            this.pick_1st.Location = new System.Drawing.Point(1021, 453);
            this.pick_1st.Name = "pick_1st";
            this.pick_1st.Size = new System.Drawing.Size(16, 16);
            this.pick_1st.TabIndex = 127;
            this.pick_1st.Text = "0";
            // 
            // pick_2nd
            // 
            this.pick_2nd.AutoSize = true;
            this.pick_2nd.Font = new System.Drawing.Font("굴림", 12F);
            this.pick_2nd.Location = new System.Drawing.Point(970, 453);
            this.pick_2nd.Name = "pick_2nd";
            this.pick_2nd.Size = new System.Drawing.Size(16, 16);
            this.pick_2nd.TabIndex = 126;
            this.pick_2nd.Text = "0";
            // 
            // pick_3rd
            // 
            this.pick_3rd.AutoSize = true;
            this.pick_3rd.Font = new System.Drawing.Font("굴림", 12F);
            this.pick_3rd.Location = new System.Drawing.Point(919, 453);
            this.pick_3rd.Name = "pick_3rd";
            this.pick_3rd.Size = new System.Drawing.Size(16, 16);
            this.pick_3rd.TabIndex = 125;
            this.pick_3rd.Text = "0";
            // 
            // pick_4th
            // 
            this.pick_4th.AutoSize = true;
            this.pick_4th.Font = new System.Drawing.Font("굴림", 12F);
            this.pick_4th.Location = new System.Drawing.Point(868, 453);
            this.pick_4th.Name = "pick_4th";
            this.pick_4th.Size = new System.Drawing.Size(16, 16);
            this.pick_4th.TabIndex = 124;
            this.pick_4th.Text = "0";
            // 
            // pick_5th
            // 
            this.pick_5th.AutoSize = true;
            this.pick_5th.Font = new System.Drawing.Font("굴림", 12F);
            this.pick_5th.Location = new System.Drawing.Point(817, 453);
            this.pick_5th.Name = "pick_5th";
            this.pick_5th.Size = new System.Drawing.Size(16, 16);
            this.pick_5th.TabIndex = 123;
            this.pick_5th.Text = "0";
            // 
            // pickodd_1st
            // 
            this.pickodd_1st.AutoSize = true;
            this.pickodd_1st.Font = new System.Drawing.Font("굴림", 12F);
            this.pickodd_1st.Location = new System.Drawing.Point(1021, 492);
            this.pickodd_1st.Name = "pickodd_1st";
            this.pickodd_1st.Size = new System.Drawing.Size(16, 16);
            this.pickodd_1st.TabIndex = 132;
            this.pickodd_1st.Text = "0";
            // 
            // pickodd_2nd
            // 
            this.pickodd_2nd.AutoSize = true;
            this.pickodd_2nd.Font = new System.Drawing.Font("굴림", 12F);
            this.pickodd_2nd.Location = new System.Drawing.Point(970, 492);
            this.pickodd_2nd.Name = "pickodd_2nd";
            this.pickodd_2nd.Size = new System.Drawing.Size(16, 16);
            this.pickodd_2nd.TabIndex = 131;
            this.pickodd_2nd.Text = "0";
            // 
            // pickodd_3rd
            // 
            this.pickodd_3rd.AutoSize = true;
            this.pickodd_3rd.Font = new System.Drawing.Font("굴림", 12F);
            this.pickodd_3rd.Location = new System.Drawing.Point(919, 492);
            this.pickodd_3rd.Name = "pickodd_3rd";
            this.pickodd_3rd.Size = new System.Drawing.Size(16, 16);
            this.pickodd_3rd.TabIndex = 130;
            this.pickodd_3rd.Text = "0";
            // 
            // pickodd_4th
            // 
            this.pickodd_4th.AutoSize = true;
            this.pickodd_4th.Font = new System.Drawing.Font("굴림", 12F);
            this.pickodd_4th.Location = new System.Drawing.Point(868, 492);
            this.pickodd_4th.Name = "pickodd_4th";
            this.pickodd_4th.Size = new System.Drawing.Size(16, 16);
            this.pickodd_4th.TabIndex = 129;
            this.pickodd_4th.Text = "0";
            // 
            // pickodd_5th
            // 
            this.pickodd_5th.AutoSize = true;
            this.pickodd_5th.Font = new System.Drawing.Font("굴림", 12F);
            this.pickodd_5th.Location = new System.Drawing.Point(817, 492);
            this.pickodd_5th.Name = "pickodd_5th";
            this.pickodd_5th.Size = new System.Drawing.Size(16, 16);
            this.pickodd_5th.TabIndex = 128;
            this.pickodd_5th.Text = "0";
            // 
            // pick40s_1st
            // 
            this.pick40s_1st.AutoSize = true;
            this.pick40s_1st.Font = new System.Drawing.Font("굴림", 12F);
            this.pick40s_1st.Location = new System.Drawing.Point(1021, 529);
            this.pick40s_1st.Name = "pick40s_1st";
            this.pick40s_1st.Size = new System.Drawing.Size(16, 16);
            this.pick40s_1st.TabIndex = 137;
            this.pick40s_1st.Text = "0";
            // 
            // pick40s_2nd
            // 
            this.pick40s_2nd.AutoSize = true;
            this.pick40s_2nd.Font = new System.Drawing.Font("굴림", 12F);
            this.pick40s_2nd.Location = new System.Drawing.Point(970, 529);
            this.pick40s_2nd.Name = "pick40s_2nd";
            this.pick40s_2nd.Size = new System.Drawing.Size(16, 16);
            this.pick40s_2nd.TabIndex = 136;
            this.pick40s_2nd.Text = "0";
            // 
            // pick40s_3rd
            // 
            this.pick40s_3rd.AutoSize = true;
            this.pick40s_3rd.Font = new System.Drawing.Font("굴림", 12F);
            this.pick40s_3rd.Location = new System.Drawing.Point(919, 529);
            this.pick40s_3rd.Name = "pick40s_3rd";
            this.pick40s_3rd.Size = new System.Drawing.Size(16, 16);
            this.pick40s_3rd.TabIndex = 135;
            this.pick40s_3rd.Text = "0";
            // 
            // pick40s_4th
            // 
            this.pick40s_4th.AutoSize = true;
            this.pick40s_4th.Font = new System.Drawing.Font("굴림", 12F);
            this.pick40s_4th.Location = new System.Drawing.Point(868, 529);
            this.pick40s_4th.Name = "pick40s_4th";
            this.pick40s_4th.Size = new System.Drawing.Size(16, 16);
            this.pick40s_4th.TabIndex = 134;
            this.pick40s_4th.Text = "0";
            // 
            // pick40s_5th
            // 
            this.pick40s_5th.AutoSize = true;
            this.pick40s_5th.Font = new System.Drawing.Font("굴림", 12F);
            this.pick40s_5th.Location = new System.Drawing.Point(817, 529);
            this.pick40s_5th.Name = "pick40s_5th";
            this.pick40s_5th.Size = new System.Drawing.Size(16, 16);
            this.pick40s_5th.TabIndex = 133;
            this.pick40s_5th.Text = "0";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("굴림", 12F);
            this.label27.Location = new System.Drawing.Point(605, 140);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(24, 16);
            this.label27.TabIndex = 139;
            this.label27.Text = "회";
            // 
            // buy_label
            // 
            this.buy_label.AutoSize = true;
            this.buy_label.Font = new System.Drawing.Font("굴림", 12F);
            this.buy_label.Location = new System.Drawing.Point(525, 140);
            this.buy_label.Name = "buy_label";
            this.buy_label.Size = new System.Drawing.Size(16, 16);
            this.buy_label.TabIndex = 140;
            this.buy_label.Text = "0";
            // 
            // draw_auto
            // 
            this.draw_auto.Location = new System.Drawing.Point(59, 126);
            this.draw_auto.Name = "draw_auto";
            this.draw_auto.Size = new System.Drawing.Size(190, 30);
            this.draw_auto.TabIndex = 141;
            this.draw_auto.Text = "자동 추첨";
            this.draw_auto.UseVisualStyleBackColor = true;
            this.draw_auto.Click += new System.EventHandler(this.draw_auto_Click);
            // 
            // draw_stop
            // 
            this.draw_stop.Location = new System.Drawing.Point(266, 126);
            this.draw_stop.Name = "draw_stop";
            this.draw_stop.Size = new System.Drawing.Size(189, 30);
            this.draw_stop.TabIndex = 142;
            this.draw_stop.Text = "자동 정지";
            this.draw_stop.UseVisualStyleBackColor = true;
            this.draw_stop.Click += new System.EventHandler(this.draw_stop_Click);
            // 
            // spent_money
            // 
            this.spent_money.AutoSize = true;
            this.spent_money.Font = new System.Drawing.Font("굴림", 12F);
            this.spent_money.Location = new System.Drawing.Point(573, 452);
            this.spent_money.Name = "spent_money";
            this.spent_money.Size = new System.Drawing.Size(16, 16);
            this.spent_money.TabIndex = 143;
            this.spent_money.Text = "0";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("굴림", 12F);
            this.label31.Location = new System.Drawing.Point(573, 338);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(56, 16);
            this.label31.TabIndex = 148;
            this.label31.Text = "구매비";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("굴림", 12F);
            this.label32.Location = new System.Drawing.Point(530, 338);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(16, 16);
            this.label32.TabIndex = 149;
            this.label32.Text = "-";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("굴림", 12F);
            this.label33.Location = new System.Drawing.Point(661, 338);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(16, 16);
            this.label33.TabIndex = 150;
            this.label33.Text = "=";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1105, 581);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.spent_money);
            this.Controls.Add(this.draw_stop);
            this.Controls.Add(this.draw_auto);
            this.Controls.Add(this.buy_label);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.pick40s_1st);
            this.Controls.Add(this.pick40s_2nd);
            this.Controls.Add(this.pick40s_3rd);
            this.Controls.Add(this.pick40s_4th);
            this.Controls.Add(this.pick40s_5th);
            this.Controls.Add(this.pickodd_1st);
            this.Controls.Add(this.pickodd_2nd);
            this.Controls.Add(this.pickodd_3rd);
            this.Controls.Add(this.pickodd_4th);
            this.Controls.Add(this.pickodd_5th);
            this.Controls.Add(this.pick_1st);
            this.Controls.Add(this.pick_2nd);
            this.Controls.Add(this.pick_3rd);
            this.Controls.Add(this.pick_4th);
            this.Controls.Add(this.pick_5th);
            this.Controls.Add(this.autopick_1st);
            this.Controls.Add(this.autopick_2nd);
            this.Controls.Add(this.autopick_3rd);
            this.Controls.Add(this.autopick_4th);
            this.Controls.Add(this.autopick_5th);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.mypick_1st);
            this.Controls.Add(this.mypick_2nd);
            this.Controls.Add(this.mypick_3rd);
            this.Controls.Add(this.mypick_4th);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.pick40s_total_money);
            this.Controls.Add(this.pick40s_earn_money);
            this.Controls.Add(this.pickodd_total_money);
            this.Controls.Add(this.pickodd_earn_money);
            this.Controls.Add(this.pick_total_money);
            this.Controls.Add(this.pick_earn_money);
            this.Controls.Add(this.autopick_total_money);
            this.Controls.Add(this.autopick_earn_money);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.mypick_total_money);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.mypick_earn_money);
            this.Controls.Add(this.mypick_5th);
            this.Controls.Add(this.pick40s_6);
            this.Controls.Add(this.pick40s_4);
            this.Controls.Add(this.pick40s_5);
            this.Controls.Add(this.pick40s_3);
            this.Controls.Add(this.pick40s_2);
            this.Controls.Add(this.pick40s_1);
            this.Controls.Add(this.pickodd_6);
            this.Controls.Add(this.pickodd_4);
            this.Controls.Add(this.pickodd_5);
            this.Controls.Add(this.pickodd_3);
            this.Controls.Add(this.pickodd_2);
            this.Controls.Add(this.pickodd_1);
            this.Controls.Add(this.pick_6);
            this.Controls.Add(this.pick_4);
            this.Controls.Add(this.pick_5);
            this.Controls.Add(this.pick_3);
            this.Controls.Add(this.pick_2);
            this.Controls.Add(this.pick_1);
            this.Controls.Add(this.autopick_6);
            this.Controls.Add(this.autopick_4);
            this.Controls.Add(this.autopick_5);
            this.Controls.Add(this.autopick_3);
            this.Controls.Add(this.autopick_2);
            this.Controls.Add(this.autopick_1);
            this.Controls.Add(this.mypick_1);
            this.Controls.Add(this.mypick_6);
            this.Controls.Add(this.mypick_5);
            this.Controls.Add(this.mypick_4);
            this.Controls.Add(this.mypick_3);
            this.Controls.Add(this.mypick_2);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.mypick_btn);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.week_label);
            this.Controls.Add(this.year_label);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.draw_520);
            this.Controls.Add(this.draw_52);
            this.Controls.Add(this.title);
            this.Controls.Add(this.bonus);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.draw_one);
            this.Name = "Form1";
            this.Text = "1,000";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button draw_one;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label bonus;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Button draw_52;
        private System.Windows.Forms.Button draw_520;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label year_label;
        private System.Windows.Forms.Label week_label;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button mypick_btn;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label mypick_2;
        private System.Windows.Forms.Label mypick_3;
        private System.Windows.Forms.Label mypick_4;
        private System.Windows.Forms.Label mypick_5;
        private System.Windows.Forms.Label mypick_6;
        private System.Windows.Forms.Label mypick_1;
        private System.Windows.Forms.Label autopick_1;
        private System.Windows.Forms.Label autopick_2;
        private System.Windows.Forms.Label autopick_3;
        private System.Windows.Forms.Label autopick_5;
        private System.Windows.Forms.Label autopick_4;
        private System.Windows.Forms.Label autopick_6;
        private System.Windows.Forms.Label pick_6;
        private System.Windows.Forms.Label pick_4;
        private System.Windows.Forms.Label pick_5;
        private System.Windows.Forms.Label pick_3;
        private System.Windows.Forms.Label pick_2;
        private System.Windows.Forms.Label pick_1;
        private System.Windows.Forms.Label pickodd_6;
        private System.Windows.Forms.Label pickodd_4;
        private System.Windows.Forms.Label pickodd_5;
        private System.Windows.Forms.Label pickodd_3;
        private System.Windows.Forms.Label pickodd_2;
        private System.Windows.Forms.Label pickodd_1;
        private System.Windows.Forms.Label pick40s_6;
        private System.Windows.Forms.Label pick40s_4;
        private System.Windows.Forms.Label pick40s_5;
        private System.Windows.Forms.Label pick40s_3;
        private System.Windows.Forms.Label pick40s_2;
        private System.Windows.Forms.Label pick40s_1;
        private System.Windows.Forms.Label mypick_earn_money;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label mypick_total_money;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label autopick_earn_money;
        private System.Windows.Forms.Label autopick_total_money;
        private System.Windows.Forms.Label pick_total_money;
        private System.Windows.Forms.Label pick_earn_money;
        private System.Windows.Forms.Label pickodd_total_money;
        private System.Windows.Forms.Label pickodd_earn_money;
        private System.Windows.Forms.Label pick40s_total_money;
        private System.Windows.Forms.Label pick40s_earn_money;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label mypick_5th;
        private System.Windows.Forms.Label mypick_4th;
        private System.Windows.Forms.Label mypick_3rd;
        private System.Windows.Forms.Label mypick_2nd;
        private System.Windows.Forms.Label mypick_1st;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label autopick_1st;
        private System.Windows.Forms.Label autopick_2nd;
        private System.Windows.Forms.Label autopick_3rd;
        private System.Windows.Forms.Label autopick_4th;
        private System.Windows.Forms.Label autopick_5th;
        private System.Windows.Forms.Label pick_1st;
        private System.Windows.Forms.Label pick_2nd;
        private System.Windows.Forms.Label pick_3rd;
        private System.Windows.Forms.Label pick_4th;
        private System.Windows.Forms.Label pick_5th;
        private System.Windows.Forms.Label pickodd_1st;
        private System.Windows.Forms.Label pickodd_2nd;
        private System.Windows.Forms.Label pickodd_3rd;
        private System.Windows.Forms.Label pickodd_4th;
        private System.Windows.Forms.Label pickodd_5th;
        private System.Windows.Forms.Label pick40s_1st;
        private System.Windows.Forms.Label pick40s_2nd;
        private System.Windows.Forms.Label pick40s_3rd;
        private System.Windows.Forms.Label pick40s_4th;
        private System.Windows.Forms.Label pick40s_5th;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label buy_label;
        private System.Windows.Forms.Button draw_auto;
        private System.Windows.Forms.Button draw_stop;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Label spent_money;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
    }
}

