﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LargeNumberLotto
{
    public partial class Form1 : Form
    {
        bool auto_fl = false;
        
        int weekcnt = 0;
        int yearcnt = 0;
        int buycnt = 0;

        int[] winningNumberList = new int[7];
        int[] mypick = new int[6];
        int[] autopick = new int[6];
        int[] pick = { 1, 2, 3, 4, 5, 6 };
        int[] pickodd = { 2, 4, 6, 8, 10, 12 };
        int[] pick40s = { 40, 41, 42, 43, 44, 45};
        long[] mypickWinnigs = new long[6];
        long[] autopickWinnigs = new long[6];
        long[] pickWinnigs = new long[6];
        long[] pickoddWinnigs = new long[6];
        long[] pick40sWinnigs = new long[6];
        Label[] mypickLabel = new Label[18];
        Label[] autopickLabel = new Label[18];
        Label[] pickLabel = new Label[18];
        Label[] pickoddLabel = new Label[18];
        Label[] pick40sLabel = new Label[18];

        public Form1()
        {
            InitializeComponent();
            label1.Text = "";
            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
            label5.Text = "";
            label6.Text = "";
            label7.Text = "";

            mypickLabel[0] = mypick_1;
            mypickLabel[1] = mypick_2;
            mypickLabel[2] = mypick_3;
            mypickLabel[3] = mypick_4;
            mypickLabel[4] = mypick_5;
            mypickLabel[5] = mypick_6;
            mypickLabel[6] = mypick_earn_money;
            mypickLabel[7] = mypick_total_money;
            mypickLabel[8] = mypick_5th;
            mypickLabel[9] = mypick_4th;
            mypickLabel[10] = mypick_3rd;
            mypickLabel[11] = mypick_2nd;
            mypickLabel[12] = mypick_1st;

            autopickLabel[0] = autopick_1;
            autopickLabel[1] = autopick_2;
            autopickLabel[2] = autopick_3;
            autopickLabel[3] = autopick_4;
            autopickLabel[4] = autopick_5;
            autopickLabel[5] = autopick_6;
            autopickLabel[6] = autopick_earn_money;
            autopickLabel[7] = autopick_total_money;
            autopickLabel[8] = autopick_5th;
            autopickLabel[9] = autopick_4th;
            autopickLabel[10] = autopick_3rd;
            autopickLabel[11] = autopick_2nd;
            autopickLabel[12] = autopick_1st;


            pickLabel[0] = pick_1;
            pickLabel[1] = pick_2;
            pickLabel[2] = pick_3;
            pickLabel[3] = pick_4;
            pickLabel[4] = pick_5;
            pickLabel[5] = pick_6;
            pickLabel[6] = pick_earn_money;
            pickLabel[7] = pick_total_money;
            pickLabel[8] = pick_5th;
            pickLabel[9] = pick_4th;
            pickLabel[10] = pick_3rd;
            pickLabel[11] = pick_2nd;
            pickLabel[12] = pick_1st;


            pickoddLabel[0] = pickodd_1;
            pickoddLabel[1] = pickodd_2;
            pickoddLabel[2] = pickodd_3;
            pickoddLabel[3] = pickodd_4;
            pickoddLabel[4] = pickodd_5;
            pickoddLabel[5] = pickodd_6;
            pickoddLabel[6] = pickodd_earn_money;
            pickoddLabel[7] = pickodd_total_money;
            pickoddLabel[8] = pickodd_5th;
            pickoddLabel[9] = pickodd_4th;
            pickoddLabel[10] = pickodd_3rd;
            pickoddLabel[11] = pickodd_2nd;
            pickoddLabel[12] = pickodd_1st;


            pick40sLabel[0] = pick40s_1;
            pick40sLabel[1] = pick40s_2;
            pick40sLabel[2] = pick40s_3;
            pick40sLabel[3] = pick40s_4;
            pick40sLabel[4] = pick40s_5;
            pick40sLabel[5] = pick40s_6;
            pick40sLabel[6] = pick40s_earn_money;
            pick40sLabel[7] = pick40s_total_money;
            pick40sLabel[8] = pick40s_5th;
            pick40sLabel[9] = pick40s_4th;
            pick40sLabel[10] = pick40s_3rd;
            pick40sLabel[11] = pick40s_2nd;
            pick40sLabel[12] = pick40s_1st;

          

        }

        private void draw_one_Click(object sender, EventArgs e)
        {
            drawLots();
        }
        private void draw_52_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 52; i++)
            {
                drawLots();
                Delay(20);
            }
            
        }

        private void draw_520_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 520; i++)
            {
                drawLots();
                Delay(1);
            }
        }
        private void draw_auto_Click(object sender, EventArgs e)
        {
            auto_fl = true;
            draw_stop.Focus();
            while (auto_fl)
            {
                drawLots();
                Delay(1);
            }
        }
        private void draw_stop_Click(object sender, EventArgs e)
        {
            auto_fl = false;
        }

        private static DateTime Delay(int MS)
        {
            DateTime ThisMoment = DateTime.Now;

            TimeSpan duration = new TimeSpan(0, 0, 0, 0, MS);

            DateTime AfterWards = ThisMoment.Add(duration);

            while (AfterWards >= ThisMoment)

            {
                System.Windows.Forms.Application.DoEvents();
                ThisMoment = DateTime.Now;
            }
            return DateTime.Now;
        }

        public void drawLots()
        {

            //모든 라벨 배경색 초기화
            initLabel();
            Random r = new Random();
            int i = 0;
            while (i < 7)
            {
                int winnigNumber = r.Next(1, 46);
                if (Array.IndexOf(winningNumberList, winnigNumber) == -1)
                {
                    winningNumberList[i] = winnigNumber;
                    i++;
                }
            }
            label1.Text = winningNumberList[0].ToString();
            label2.Text = winningNumberList[1].ToString();
            label3.Text = winningNumberList[2].ToString();
            label4.Text = winningNumberList[3].ToString();
            label5.Text = winningNumberList[4].ToString();
            label6.Text = winningNumberList[5].ToString();
            label7.Text = winningNumberList[6].ToString();
            
            if(mypick[0] == 0)
            {
                execMypick();
            }
            execAutoPick();

            checkWin(mypick, mypickWinnigs, mypickLabel);
            checkWin(autopick, autopickWinnigs, autopickLabel);
            checkWin(pick, pickWinnigs, pickLabel);
            checkWin(pickodd, pickoddWinnigs, pickoddLabel);
            checkWin(pick40s, pick40sWinnigs, pick40sLabel);

            //카운트 올리기
            buycnt += 1;
            weekcnt++;
            if (weekcnt == 52)
            {
                weekcnt = 0;
                yearcnt++;
            }
            buy_label.Text = buycnt.ToString();
            week_label.Text = weekcnt.ToString();
            year_label.Text = yearcnt.ToString();
        }

        private void initLabel()
        {
            foreach(Control con in this.Controls)
            {
                if (con.GetType() == typeof(Label))
                {
                    con.BackColor = Color.Empty;
                }
            }
        }

        private void checkWin(int[] picks , long[] winnings, Label[] labels )
        {
            int win = 0;
            for (int i = 0; i < 6; i++)
            {
                int index = Array.IndexOf(picks, winningNumberList[i]);
                if (index != -1)
                {
                    win++;
                    //맞은번호 색칠
                    switch (index)
                    {
                        case 0:
                            labels[0].BackColor = Color.Aqua;
                            break;
                        case 1:
                            labels[1].BackColor = Color.Aqua;
                            break;
                        case 2:
                            labels[2].BackColor = Color.Aqua;
                            break;
                        case 3:
                            labels[3].BackColor = Color.Aqua;
                            break;
                        case 4:
                            labels[4].BackColor = Color.Aqua;
                            break;
                        case 5:
                            labels[5].BackColor = Color.Aqua;
                            break;
                    }
                }
                if (win == 3) //5등
                {
                    winnings[0] += 1;
                    winnings[5] += 5000;

                }
                else if (win == 4)//4등
                {
                    winnings[1] += 1;
                    winnings[5] += 50000;
                }
                else if (win == 5)
                {
                    //3등
                    if (Array.IndexOf(pick40s, winningNumberList[6]) == -1)
                    {
                        winnings[2] += 1;
                        winnings[5] += 2000000;
                    }
                    else//2등
                    {
                        winnings[3] += 1;
                        winnings[5] += 100000000;
                    }
                }
                else if (win == 6)
                {
                    winnings[4] += 1;
                    winnings[5] += 5000000000;
                    MessageBox.Show("1등이라니 ㄷㄷㄷㄷㄷ");
                }
                else//낙첨
                {
                    labels[6].Text = "0";
                }
            }

            //누적당첨금표시부분
            spent_money.Text = (buycnt * 1000).ToString();
            labels[6].Text = (winnings[5] - (buycnt * 1000)).ToString();
            labels[7].Text = winnings[5].ToString();

            //당첨 횟수 누적 표시부분
            labels[8].Text = winnings[0].ToString();
            labels[9].Text = winnings[1].ToString();
            labels[10].Text = winnings[2].ToString();
            labels[11].Text = winnings[3].ToString();
            labels[12].Text = winnings[4].ToString();

        }
        
        private void mypick_btn_Click(object sender, EventArgs e)
        {
            execMypick();
        }

        private void execAutoPick()
        {
            //랜덤 시드 배정문제로 스레드 슬립
            Thread.Sleep(17);
            Random r = new Random();

            int i = 0;
            while (i < 6)
            {
                int autopickNum = r.Next(1, 46);
                if (Array.IndexOf(autopick, autopickNum) == -1)
                {
                    autopick[i] = autopickNum;
                    i++;
                }
            }

            Array.Sort(autopick);
            autopick_1.Text = autopick[0].ToString();
            autopick_2.Text = autopick[1].ToString();
            autopick_3.Text = autopick[2].ToString();
            autopick_4.Text = autopick[3].ToString();
            autopick_5.Text = autopick[4].ToString();
            autopick_6.Text = autopick[5].ToString();

        }

        private void execMypick()
        {
            //랜덤 시드 배정문제로 스레드 슬립
            Thread.Sleep(30);
            Random r = new Random();
            int temp;
          
            //1은 무조건 넣음
            if (!int.TryParse(textBox1.Text, out mypick[0]))
            {
                mypick[0] = r.Next(1, 46);
            }
            if(mypick[0]>=46 || mypick[0] <= 0)
            {
                mypick[0] = r.Next(1, 46);
            }

            //2부터는 없을때만 넣음

            if (!int.TryParse(textBox2.Text, out temp))
            {
                temp = r.Next(1, 46);
            }
            while (Array.IndexOf(mypick, temp) != -1)
            {
                temp = r.Next(1, 46);
            }
            mypick[1] = temp;
            if (!int.TryParse(textBox3.Text, out temp))
            {
                temp = r.Next(1, 46);
            }
            while (Array.IndexOf(mypick, temp) != -1)
            {
                temp = r.Next(1, 46);
            }
            mypick[2] = temp;

            if (!int.TryParse(textBox4.Text, out temp))
            {
                temp = r.Next(1, 46);
            }
            while (Array.IndexOf(mypick, temp) != -1)
            {
                temp = r.Next(1, 46);
            }
            mypick[3] = temp;

            if (!int.TryParse(textBox5.Text, out temp))
            {
                temp = r.Next(1, 46);
            }
            while (Array.IndexOf(mypick, temp) != -1)
            {
                temp = r.Next(1, 46);
            }
            mypick[4] = temp;

            if (!int.TryParse(textBox6.Text, out temp))
            {
                temp = r.Next(1, 46);
            }
            while (Array.IndexOf(mypick, temp) != -1)
            {
                temp = r.Next(1, 46);
            }
            mypick[5] = temp;

            Array.Sort(mypick);

            mypick_1.Text = mypick[0].ToString();
            mypick_2.Text = mypick[1].ToString();
            mypick_3.Text = mypick[2].ToString();
            mypick_4.Text = mypick[3].ToString();
            mypick_5.Text = mypick[4].ToString();
            mypick_6.Text = mypick[5].ToString();
        }

        
    }
}
